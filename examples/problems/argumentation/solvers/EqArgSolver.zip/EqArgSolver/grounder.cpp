/*
 * grounder.cpp
 *
 *  Created on: 11 Mar 2016
 *      Author: stty3154
 */

#include "grounder.h"

using namespace std;

// Approximates the limit values until the rounding error is greater
// then the maximum variation in node values

//////////////////////////////////////////////////////////////////////////////
//
// process_mem_usage(double &, double &) - takes two doubles by reference,
// attempts to read the system-dependent data for a process' virtual memory
// size and resident set size, and return the results in KB.
//
// On failure, returns 0.0, 0.0

void
process_mem_usage(double& vm_usage, double& resident_set)
{
   using std::ios_base;
   using std::ifstream;
   using std::string;

   vm_usage     = 0.0;
   resident_set = 0.0;

   // 'file' stat seems to give the most reliable results
   //
   ifstream stat_stream("/proc/self/stat",ios_base::in);

   // dummy vars for leading entries in stat that we don't care about
   //
   string pid, comm, state, ppid, pgrp, session, tty_nr;
   string tpgid, flags, minflt, cminflt, majflt, cmajflt;
   string utime, stime, cutime, cstime, priority, nice;
   string O, itrealvalue, starttime;

   // the two fields we want
   //
   unsigned long vsize;
   long rss;

   stat_stream >> pid >> comm >> state >> ppid >> pgrp >> session >> tty_nr
               >> tpgid >> flags >> minflt >> cminflt >> majflt >> cmajflt
               >> utime >> stime >> cutime >> cstime >> priority >> nice
               >> O >> itrealvalue >> starttime >> vsize >> rss; // don't care about the rest

   stat_stream.close();

   long page_size_kb = sysconf(_SC_PAGE_SIZE) / 1024; // in case x86-64 is configured to use 2MB pages
   vm_usage     = vsize / 1024.0;
   resident_set = rss * page_size_kb;
}

unsigned long long
getTotalSystemMemory()
{
    long pages = sysconf(_SC_PHYS_PAGES);
    long page_size = sysconf(_SC_PAGE_SIZE);
    return pages * page_size;
}

void mem_stats() {
  double vm, rss;
  process_mem_usage(vm, rss);
  cout.precision(0);
  cout << "Memory stats: Total memory: " << (getTotalSystemMemory()/(1024^3))
       << fixed << "Gb VM: " << (vm/(1024*1024))
       << "Mb RSS: " << (rss/(1024^2)) << "Mb";
};

void full_approx_grounder (unordered_set<string> * nodeList,
      map<string, vector<string> > * attsIn,
      map<string, double> * initArray,
      map<string, double> * stableArray,
      map<string, double> * equilArray,
      bool verbose,
      double tolerance) {

  map<string, double> vi;
  map<string, double> deltamax;
  map<string, double> deltainv;
  vector<string> attackers;
  double maxdiff = 1;
  bool stable, prevStable, thisIterStable;
  stable = false;
  unsigned int iterNum = 0;
  double maxatt, delta;
  string inputStr;

  // Copying initial values into the previous iteration values vector, i.e., "vi"
  for (map<string, double>::iterator it = (*initArray).begin ();
      it != (*initArray).end (); ++it) {
    vi[it->first] = it->second;
  };

  // Calculating next iteration...
  // The main loop below contain iterations in which at least
  // one node changes values from crisp to undecided.
  // We use it to create intermediate GIF files for the main
  // animation.

  while (((!stable) && (iterNum < (vi.size () + 1))) || (maxdiff > tolerance)) {
    iterNum++;
    maxdiff = 0;
    prevStable = stable;
    thisIterStable = true;
    for (unordered_set<string>::iterator it = (*nodeList).begin ();
	it != (*nodeList).end (); it++) {
      maxatt = 0;
      attackers = (*attsIn)[*it];
      vector<string>::iterator it2 = attackers.begin ();
      deltainv[*it] = 1;
      while (it2 != attackers.end ()) {
	deltainv[*it] = deltainv[*it] * (1 - vi[*it2]);
	maxatt = max (maxatt, vi[*it2]);
	it2++;
      };
      deltamax[*it] = 1 - maxatt;
      delta = deltamax[*it];
      (*equilArray)[*it] = ((1 - vi[*it]) * min (0.5, delta))
	+ (vi[*it] * max (0.5, delta));
      thisIterStable = (thisIterStable
			&& !(((vi[*it] == 1) && ((*equilArray)[*it] < 1))
			     || ((vi[*it] == 0) && ((*equilArray)[*it] > 0))));
      maxdiff = max (maxdiff,fabs((*equilArray)[*it] - vi[*it]));
    };
    stable = thisIterStable;
    if (!prevStable && stable) {
      for (unordered_set<string>::iterator it = (*nodeList).begin ();
	  it != (*nodeList).end (); ++it) {
	(*stableArray)[*it] = (*equilArray)[*it];
      };
    };

    for (unordered_set<string>::iterator it = (*nodeList).begin ();
	it != (*nodeList).end (); ++it) {
      vi[*it] = (*equilArray)[*it];
    };
  };
}

string
getArgLabel(IntArgValue_T argValue) {
  if (argValue == IN) {
    return "I";
  } else {
    if (argValue == OUT) {
      return "O";
    } else {
      if (argValue == MUST_OUT) {
        return "MO";
      } else {
	if (argValue == UND) {
	  return "U";
	} else {
	  return "B";
	};
      };
    };
  };
};

void fastGrounder (unordered_set<string> * nodeList,
                   map<string, vector<string> > * attsIn,
                   map<string, double> * initArray,
                   map<string, double> * stableArray,
                   map<string, double> * equilArray, bool verbose,
                   double tolerance) {

  map<string, double> vi;
  map<string, double> deltamax;
  vector<string> attackers;
  double maxdiff = 1;
  bool stable, prevStable, thisIterStable;
  stable = false;
  unsigned int iterNum = 0;
  double maxatt; //, delta;
  string inputStr;

  // Copying initial values into the previous iteration values vector, i.e., "vi"
  for (map<string, double>::iterator it = (*initArray).begin ();
      it != (*initArray).end (); ++it) {
    vi[it->first] = it->second;
  };

  // Calculating next iteration...
  // The main loop below contain iterations in which at least
  // one node changes values from crisp to undecided.
  // We use it to create intermediate GIF files for the main
  // animation.

  while (((!stable) && (iterNum < (vi.size () + 1))) || (maxdiff > tolerance)) {
    iterNum++;
    maxdiff = 0;
    prevStable = stable;
    thisIterStable = true;
    for (unordered_set<string>::iterator it = (*nodeList).begin ();
        it != (*nodeList).end (); it++) {
      maxatt = 0;
      attackers = (*attsIn)[*it];
      vector<string>::iterator it2 = attackers.begin ();
      while (it2 != attackers.end ()) {
        maxatt = max (maxatt, vi[*it2]);
        it2++;
      };
      deltamax[*it] = 1 - maxatt;
      // delta = deltamax[*it];
      (*equilArray)[*it] = 1 - maxatt;
      thisIterStable = (thisIterStable
          && !(((vi[*it] == 1) && ((*equilArray)[*it] < 1))
              || ((vi[*it] == 0) && ((*equilArray)[*it] > 0))));
      maxdiff = max (maxdiff, fabs ((*equilArray)[*it] - vi[*it]));
    };
    stable = thisIterStable;
    if (!prevStable && stable) {
      for (unordered_set<string>::iterator it = (*nodeList).begin ();
          it != (*nodeList).end (); ++it) {
        (*stableArray)[*it] = (*equilArray)[*it];
      };
    };

    for (unordered_set<string>::iterator it = (*nodeList).begin ();
        it != (*nodeList).end (); ++it) {
      vi[*it] = (*equilArray)[*it];
    };
  };
}

void efficientGrounder (const unordered_set<IntArgId_T> & nodeList,
			const unordered_map<IntArgId_T, ArgNode_T> & argList,
			const sol_type & v0,
			sol_type & ve) {

  map<IntArgId_T, double> vi;
  map<IntArgId_T, double> deltamax;
  vector<IntArgId_T> attackers;
  bool stable, thisIterStable;
  IntArgValue_T maxatt;

  // Copying initial values into the previous iteration values vector, i.e., "vi"
  for (map<IntArgId_T, IntArgValue_T>::const_iterator it = v0.begin();
      it != v0.end(); ++it) {
    vi[it->first] = it->second;
  };
//  cout << "Copied values to V0" << endl;
  // Calculating next iteration...
  // The main loop below contain iterations in which at least
  // one node changes values from crisp to undecided.

  stable = false;
  unsigned int iterNum = 0;
  // Upper bound here is vi.size()+1
  while ((!stable) && (iterNum < (vi.size() + 1))) {
    thisIterStable = true;
//    cout << "Iteration " << iterNum << endl;
    for (unordered_set<IntArgId_T>::const_iterator it = nodeList.begin();
        it != nodeList.end (); it++) {
      maxatt = OUT; // The initial maximum value of an attacker of
                    // the node (*it)
      // attackers = (*argList)[*it].attsIn;
      vector<IntArgId_T>::const_iterator it2 = argList.at(*it).attsIn.begin ();
      // Iterate through this node's attackers
      while (it2 != argList.at(*it).attsIn.end ()) {
        maxatt=(maxatt > vi[*it2]) ? maxatt : vi[*it2];
        it2++;
      };
      // The new value of node (*it) is now calculated
      // as IN - the maximum value of any of its attackers:
      ve[*it] = IN - maxatt;

      // This iteration is stable if no nodes changed their
      // previous values
      thisIterStable = (thisIterStable && (ve[*it] == vi[*it]));
    };
    stable = thisIterStable;
    if (!thisIterStable) {
      for (unordered_set<IntArgId_T>::const_iterator it = nodeList.begin ();
	   it != nodeList.end (); ++it) {
	   vi[*it] = ve[*it];
      };
    };

    iterNum++; // Advance to the next iteration
  };
  /*
  cout << "Total number of iterations: " << (iterNum-1) << endl;
  cout << "Stable? " << stable << endl;
  wait();
  */
}

void sccGrounder (const set<IntArgId_T> & nodeList,
		  const unordered_map<IntArgId_T, ArgNode_T> & argList,
		  const map<IntArgId_T, IntArgValue_T> & v0,
		  map<IntArgId_T, IntArgValue_T> & ve) {

  map<IntArgId_T, IntArgValue_T> vi;
  map<IntArgId_T, IntArgValue_T> deltamax;
  vector<IntArgId_T> attackers;
  bool stable, thisIterStable;
  IntArgValue_T maxatt;
  
  // Copying initial values into the previous iteration values vector, i.e., "vi"
  vi=v0;
  // clock_t _start_time = clock();
  // cout << clock() - _start_time << endl;
  for (auto node : nodeList) {
    vi[node] = UND;
    // cout << "Setting SCC initial values. " << argList.at(node).extArgId <<
    //   "=" << getArgLabel(UND) << endl;
  };
  //  cout << "Copied values to V0" << endl;
  // Calculating next iteration...
  // The main loop below contain iterations in which at least
  // one node changes values from crisp to undecided.
  
  stable = false;
  unsigned int iterNum = 0;
  // Upper bound here is vi.size()+1
  while ((!stable) && (iterNum < (vi.size() + 1))) {
    thisIterStable = true;
    //    cout << "Iteration " << iterNum << endl;
    for (set<IntArgId_T>::const_iterator it = nodeList.begin();
	 it != nodeList.end (); it++) {
      maxatt = OUT; // The initial maximum value of an attacker of
                    // the node (*it)
      // attackers = (*argList)[*it].attsIn;
      vector<IntArgId_T>::const_iterator it2 = argList.at(*it).attsIn.begin ();
      // Iterate through this node's attackers
      while (it2 != argList.at(*it).attsIn.end ()) {
        maxatt=(maxatt > vi[*it2]) ? maxatt : vi[*it2];
        it2++;
      };
      // The new value of node (*it) is now calculated
      // as IN - the maximum value of any of its attackers:
      ve[*it] = IN - maxatt;
      
      // This iteration is stable if no nodes changed their
      // previous values
      thisIterStable = (thisIterStable && (ve[*it] == vi[*it]));
    };
    stable = thisIterStable;
    if (!thisIterStable) {
      for (set<IntArgId_T>::const_iterator it = nodeList.begin ();
	   it != nodeList.end (); ++it) {
	vi[*it] = ve[*it];
      };
    };
    
    iterNum++; // Advance to the next iteration
  };
}

void trivialGrounder (const set<IntArgId_T> & nodeList,
                      const unordered_map<IntArgId_T, ArgNode_T> & argList,
                      const sol_type & v0,
                      sol_type & trivialSol) {

  // Topologically ordering the nodes of the trivial SCC block
  bool sourceNode;
  queue<IntArgId_T> topoOrder;
  deque<IntArgId_T> orderedTrivials;
  unordered_map<IntArgId_T,IntArgId_T> degree;
  degree.reserve(nodeList.size());
  for (set<IntArgId_T>::iterator it=nodeList.begin();
      it!=nodeList.end(); it++) {
    degree[*it]=0;
  };
  // First source nodes:
  for (set<IntArgId_T>::iterator it2=nodeList.begin();
      it2!=nodeList.end(); it2++) {
    sourceNode = true;
    for (vector<IntArgId_T>::const_iterator attIt=argList.at(*it2).attsIn.begin(); 
        attIt!=argList.at(*it2).attsIn.end(); attIt++) {
      if (argList.at(*attIt).layer == argList.at(*it2).layer) {
        degree[*it2]=degree[*it2]+1;
        sourceNode = false;
      }
    }
    if (sourceNode) {
      topoOrder.push(*it2);
    };
  };
  // Ready to process topoOrder....
  while (!topoOrder.empty()) {
    IntArgId_T thisNode = topoOrder.front();
    orderedTrivials.push_back(thisNode);
    topoOrder.pop();
    for (vector<IntArgId_T>::const_iterator attIt=argList.at(thisNode).attsOut.begin();
        attIt!=argList.at(thisNode).attsOut.end(); attIt++) {
      degree[*attIt]--;
      if (degree[*attIt]==0) {
        topoOrder.push(*attIt);
      }
    }
  }
  // orderedTrivials now contains the nodes in nodeList sorted in topological order
  map<IntArgId_T, IntArgValue_T> vi, ve;
  map<IntArgId_T, IntArgValue_T> deltamax;
  vector<IntArgId_T> attackers;
  IntArgValue_T maxatt;
  // int ctr = 0;
  // Copying initial values into the previous iteration values vector, i.e., "vi"
  if (v0.empty()) {
    for (auto it : orderedTrivials) {
      vi[it]=UND;
    };
  } else {
    for (auto it : v0) {
      ve[it.first] = it.second;
    };
    for (auto it : orderedTrivials) {
      vi[it] = UND;
    };
  };
  // Calculating next iteration...
  // The main loop below contain iterations in which at least
  // one node changes values from crisp to undecided.

  // Upper bound here is vi.size()+1
  for (deque<IntArgId_T>::const_iterator it = orderedTrivials.begin();
      it != orderedTrivials.end(); ++it) {
    // cout << "Processing " << argList.at(*it).extArgId << endl;
    vector<IntArgId_T>::const_iterator it2 = argList.at(*it).attsIn.begin();
    // Iterate through this node's attackers
    maxatt = OUT;
    while (it2 != argList.at(*it).attsIn.end ()) {
      maxatt=(maxatt > ve[*it2]) ? maxatt : ve[*it2];
      // cout << argList.at(*it2).extArgId << "=" << getArgLabel(ve[*it2]) << endl;
      it2++;
    };
    // The new value of node (*it) is now calculated
    // as IN - the maximum value of any of its attackers:
    ve[*it] = IN - maxatt;
  };
  // Copying only relevant values to trivialSol:
  for (auto node : orderedTrivials) {
    trivialSol[node] = ve[node];
  };
}

void bestGrounder (unordered_set<IntArgId_T> * nodeList,
		   map<IntArgId_T, vector<IntArgId_T> > * attsIn,
		   map<IntArgId_T, IntArgValue_T> * baseSolution,
		   map<IntArgId_T, IntArgValue_T> * groundedSolution) {

  map<IntArgId_T, double> vi;
  map<IntArgId_T, double> deltamax;
  vector<IntArgId_T> attackers;
  bool stable, thisIterStable;
    IntArgValue_T maxatt;

  // Copying initial values into the previous iteration values vector, i.e., "vi"
  for (map<IntArgId_T, IntArgValue_T>::iterator it = (*baseSolution).begin();
      it != (*baseSolution).end (); ++it) {
    vi[it->first] = it->second;
  };

  // Calculating next iteration...
  // The main loop below contain iterations in which at least
  // one node changes values from crisp to undecided.

  stable = false;
  while (!stable) {
    thisIterStable = true;
    for (unordered_set<IntArgId_T>::iterator it = (*nodeList).begin();
        it != (*nodeList).end (); it++) {
      maxatt = OUT; // The initial maximum value of an attacker of
                    // the node (*it)
      attackers = (*attsIn)[*it];
      for (vector<IntArgId_T>::iterator it2=attackers.begin();
	   it2 != attackers.end(); ++it2) {
        maxatt=(maxatt > vi[*it2]) ? maxatt : vi[*it2];
      };
      // The new value of node (*it) is now calculated
      // as IN - the maximum value of any of its attackers:
      (*groundedSolution)[*it] = IN - maxatt;

      // This iteration is stable if no nodes changed their
      // previous values
      thisIterStable = (thisIterStable && !((*groundedSolution)[*it] != vi[*it]));
    };
    stable = thisIterStable;

    for (unordered_set<IntArgId_T>::iterator it = (*nodeList).begin ();
        it != (*nodeList).end (); ++it) {
      vi[*it] = (*groundedSolution)[*it];
    };
    // iterNum++; // Advance to the next iteration
  };
}

/*
void oldEfficientGrounder (unordered_set<string> * nodeList,
                   map<string, vector<string> > * attsIn,
                   map<string, IntArgValue_T> * initArray,
                   map<string, IntArgValue_T> * equilArray) {

  map<string, double> vi;
  map<string, double> deltamax;
  vector<string> attackers;
  bool stable, thisIterStable;
  IntArgValue_T maxatt;

  // Copying initial values into the previous iteration values vector, i.e., "vi"
  for (map<string, IntArgValue_T>::iterator it = (*initArray).begin ();
      it != (*initArray).end (); ++it) {
    vi[it->first] = it->second;
  };

  // Calculating next iteration...
  // The main loop below contain iterations in which at least
  // one node changes values from crisp to undecided.

  stable = false;
  unsigned int iterNum = 0;
  while ((!stable) && (iterNum < (vi.size() + 1))) {
    thisIterStable = true;
    for (unordered_set<string>::iterator it = (*nodeList).begin();
        it != (*nodeList).end (); it++) {
      maxatt = OUT; // The initial maximum value of an attacker of
                    // the node (*it)
      attackers = (*attsIn)[*it];
      vector<string>::iterator it2 = attackers.begin ();
      // Iterate through this node's attackers
      while (it2 != attackers.end ()) {
        maxatt=(maxatt > vi[*it2]) ? maxatt : vi[*it2];
        it2++;
      };
      // The new value of node (*it) is now calculated
      // as IN - the maximum value of any of its attackers:
      (*equilArray)[*it] = IN - maxatt;

      // This iteration is stable if no nodes changed their
      // previous values
      thisIterStable = (thisIterStable && !((*equilArray)[*it] != vi[*it]));
    };
    stable = thisIterStable;

    for (unordered_set<string>::iterator it = (*nodeList).begin ();
        it != (*nodeList).end (); ++it) {
      vi[*it] = (*equilArray)[*it];
    };
    iterNum++; // Advance to the next iteration
  };
}

*/

bool condPropagate (unordered_set<IntArgId_T> * nodeList,
		    IntArgId_T argToMakeIN,
		    map<IntArgId_T, vector<IntArgId_T> > * attsIn,
		    unordered_set<IntArgId_T> * def_outs,
		    map<IntArgId_T, IntArgValue_T> * initSolution,
		    map<IntArgId_T, IntArgValue_T> * equilArray) {
  /*
    INPUT:
    - A list of nodes where the propagation is to take place
    - Nodes whose values are conditioned by the solution to be OUT
    - A partial solution initSolution

    OUTPUT:
    - true, if propagation is successful and the result of propagation in
      the array equilArray
    - false, if propagation cannot be done successfully
  */

  map<IntArgId_T, double> vi;
  map<IntArgId_T, double> deltamax;
  vector<IntArgId_T> attackers;
  bool stable, thisIterStable;
  IntArgValue_T maxatt;

  // Copying initial values into the previous iteration values vector, i.e., "vi"
  for (map<IntArgId_T, IntArgValue_T>::iterator it = (*initSolution).begin ();
      it != (*initSolution).end (); ++it) {
    vi[it->first] = it->second;
  };
  vi[argToMakeIN]=IN;

  // Calculating next iteration...
  // The main loop below contain iterations in which at least
  // one node changes values from crisp to undecided.

  stable = false;
  unsigned int iterNum = 0;
  bool error = false;
  while ((!stable) && (iterNum < (vi.size() + 1)) && !error) {
    thisIterStable = true;
    for (unordered_set<IntArgId_T>::iterator it = (*nodeList).begin();
        it != (*nodeList).end (); it++) {
      maxatt = OUT; // The initial maximum value of an attacker of
                    // the node (*it)
      attackers = (*attsIn)[*it];
      vector<IntArgId_T>::iterator it2 = attackers.begin ();
      // Iterate through this node's attackers
      while (it2 != attackers.end ()) {
        maxatt=(maxatt > vi[*it2]) ? maxatt : vi[*it2];
        it2++;
      };
      // The new value of node (*it) is now calculated
      // as IN - the maximum value of any of its attackers:
      (*equilArray)[*it] = IN - maxatt;

      // This iteration is stable if no nodes changed their
      // previous values
      thisIterStable = (thisIterStable && !((*equilArray)[*it] != vi[*it]));
    };
    stable = thisIterStable;

    for (unordered_set<IntArgId_T>::iterator it = (*nodeList).begin ();
        it != (*nodeList).end (); ++it) {
      vi[*it] = (*equilArray)[*it];
    };
    iterNum++; // Advance to the next iteration
  };
  unordered_set<IntArgId_T>::iterator it = def_outs->begin ();
  while ((it != def_outs->end()) && !error) {
    error = ((*equilArray)[*it] != OUT);
    if (error) {
      cout << "ERROR: Equilibrium value of " << *it << "="
	   << to_string((*equilArray)[*it]) << " whereas its conditioned value was "
	   << to_string(OUT) << "." << endl;
    };
    it++;
  };
  return (stable && !error);
}


