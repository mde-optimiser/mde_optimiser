// DEVELOPMENT HISTORY:
// 2.74: Ground only relevant SCCs, as grounding layer was taking
// too long in some problems.

/*
 Copyright (c) 2017 Odinaldo Rodrigues.
 King's College London.

 Compile with
   g++ -std=c++11 -c grounder.cpp
   g++ -std=c++11 -c eqargsolver-2.2.cpp
   g++ -o eqargsolver-2.2 eqargsolver-2.2.o grounder.o

 EqArgSolver is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.

 v2.2: This version can be used in decision and enumeration problems
 for the grounded, complete, preferred and stable semantics.

 Computation is done via decomposition of the network into layers,
 which are then successively processed. The outline of execution is
 more or less as follows.

  1. The graph is divided into SCCs and arranged into layers
  2. The trivial SCCs in a layer are combined and jointly processed.
     Each non-trivial SCC in a layer is processed individually
     in ascending layer order.
  3. Each layer is conditioned by a partial solution for
     the previous layers. The conditioning values are propagated using a
     grounding mechanism based on the discrete Gabbay-Rodrigues iteration
     schema. The grounding resolves all nodes in trivial SCCs of
     that layer and possibly some nodes in the non-trivial SCCs.
  4. However, some nodes in the non-trivial SCCs may still be left
     undecided. Finding legal values in the set {0,1} for these nodes
     give rise to complete extensions that may be larger than the
     grounded extension.
    4.1 The remaining undecided nodes cannot be attacked by any node that
        is legally IN (otherwise the grounding would have labelled
	      them OUT). This means that within each working layer conditioned by a
        partial solution to the previous layers, some nodes could possibly
	      be labelled IN resulting in a complete extension larger than the
	      in the extension originally computed.
    4.3 The algorithm tries to label each of these nodes IN in sequence, propagating
        the label forwards and backwards as needed. Of course in a cyclic SCC, the
	      propagation may not succeed, but if it does, this will generate a new
        (larger) extension. This process is applied recursively until no further
        extensions can be generated. This produces all new partial solutions up to
	      the current layer and the process continues until all layers have been
	      processed.
    4.4 The maximal extensions obtained in this way are the preferred extensions.
        If a preferred extension has no undecided nodes, then it is also stable.

 */

#include <map>
#include <memory>
#include <unordered_map>
#include <sstream>
#include <fstream>
#include <iostream>
#include <deque>
#include <queue>
#include <set>
#include <vector>
#include <stack>
#include <cmath>
#include <algorithm>
#include <string>
#include <limits>
#include <ctype.h>
#include <string.h>
#include <time.h>
#include <iomanip>
#include "grounder.h"
#include <stdlib.h>
#include <sys/resource.h>

using namespace std;

class
timer {
  clock_t _start_time;
  clock_t _accummulated;
  bool _paused;

public:
  timer () {
    _start_time=clock();
    _accummulated=0;
    _paused=true;
  }
  void
  reset () {
    _accummulated=0;
    _paused=true;
  }
  void
  resume() {
    _start_time = clock();
    _paused=false;
  }
  void
  pause() {
    if (!_paused) {
      _accummulated=_accummulated+(clock()-_start_time);
      _paused=true;
    };
  }
  int
  elapsed () const {
    return int (_accummulated) / CLOCKS_PER_SEC;
  }
  float
  milli_elapsed () const {
    if (_paused) {
      return float (_accummulated) / CLOCKS_PER_SEC;
    } else {
      return float (_accummulated+(clock()-_start_time)) / CLOCKS_PER_SEC;
    }
  }
};

struct setHash {
  size_t operator()(unordered_set<IntArgId_T> const& theSet) const {
    int result=0;
    for (unordered_set<IntArgId_T>::const_iterator it=theSet.begin(); it!=theSet.end(); it++) {
      result = result + pow(2.0,*it);
    };
    return (result % 300000);
  }
};

struct argHash {
  size_t operator()(IntArgId_T const& argId) const {
    return argId;
  }
};

struct
nodeTuple
{
  int index;
  int lowindex;
  bool isRemoved;
};

struct
sccTuple
{
  set<IntArgId_T> nodes;
  int level, layer;
  set<IntArgId_T> parents;
  set<sccTuple *> myParentSCCs;
  bool levelFound;
  bool isTrivial;
};

struct
sccLayerTuple
{
  sccTuple trivialSCC;
  vector<sccTuple *> nonTrivialSCCs;
};

struct
sccPair
{
  IntArgId_T node;
  IntArgId_T parent;
};

struct
solNode {
  sol_type * solValue;
  solNode * parent;
  set<solNode *> children;
};

// Global variables:

const unsigned char MOS_ODIN = 0;
const unsigned char MODGIL_CAMINADA = 1;
const unsigned char NOFAL = 2;
const unsigned char NOF_ODI = 3;
const unsigned char ODIN_PURE = 4;
const short int FIRST = -1;
const short int MAX_OUT = 0;
const short int MIN_OUT = 1;
const short int MAX_IN = 2;
const short int MIN_IN = 3;
short int __policy = MAX_OUT;
map<string, string> problem;
unordered_map<ExtArgId_T, IntArgId_T> intArgId;
unordered_map<IntArgId_T, ArgNode_T> argList;
vector<string> supportedFormats;
vector<string> supportedProbs;
IntArgId_T totArgs, totEdges, totSCCs;
bool decisionProblem = false;
int tolerance = std::numeric_limits<long int>::epsilon ();
int min_int = std::numeric_limits<int>::min();
int prefCtr = 0;
int stepCtr = 0;
int findExtsCtr = 0;
bool quickMode = false;
bool debug = false;
bool deep = false;
bool verbOutput = false;
bool stepCount = false;
bool checkSols = false;
bool useConflicts = false;
bool trace = false;
bool skeptical, stableSemantics, stableSafe, globalSuccess, groundedSemantics, triathlon;
unsigned char sccCompMethod = ODIN_PURE;
IntArgId_T intArgToFind;
vector<sccLayerTuple *> sccLayers;
string executableName, solutionName;
size_t savedFromConflicts, totConflicts, numRecCalls, intMaxSols=0, maxSols=0;
timer updTime, insTime, cmpTime, stratTimer, groundingTimer, solutionTimer, compositionTimer, globalTimer, selectTimer, poss_in_timer;
stringstream bugstr;

string
getCompMethodName(const short int methodCode) {
  switch (methodCode) {
    case 0:  return "MOS_ODIN";
    case 1:  return "MODGIL_CAMINADA";
    case 2:  return "NOFAL";
    case 3:  return "NOF_ODI";
    case 4:  return "ODIN_PURE";
    default: return "ODINALDO";
  }
}

string
getStrategyName(const short int strategyCode) {
  switch (strategyCode) {
    case -1: return "FIRST";
    case 0: return "MAX_OUT";
    case 1: return "MIN_OUT";
    case 2: return "MAX_IN";
    case 3: return "MIN_IN";
    default: return "FIRST";
  }
}

string
getStrategyCode(const short int strategyCode) {
  switch (strategyCode) {
    case -1: return "-1";
    case 0: return "0";
    case 1: return "1";
    case 2: return "2";
    case 3: return "3";
    default: return "-1";
  }
}

void
set_stats (size_t thisSavedFromConflicts, size_t numConflicts, size_t numSols) {
  savedFromConflicts = savedFromConflicts + thisSavedFromConflicts;
  totConflicts = max(totConflicts,numConflicts);
  if (numSols > maxSols) { maxSols=numSols; };
}

void
display_stats() {
  cout << "========================================================" << endl;
  cout << "Policy " << getStrategyName(__policy) << " stats:" << endl;
  cout << "Number of recursive calls: " << numRecCalls << endl;
  cout << "Savings" << endl;
  cout << "--------------------------------------------------------" << endl;
  cout << "Max conflicts learnt: " << totConflicts << endl;
  cout << "Saved from conflicts: " << savedFromConflicts << endl;
  cout << "Max num of SCC sols:  " << maxSols << endl;
  /*
  cout << "Time spent on updates: " << updTime.elapsed() << "s" << endl;
  cout << "Time spent on solution insertion: " <<insTime.elapsed() << "s" << endl;
  cout << "Time spent on comparisons: " << cmpTime.elapsed() << "s" << endl;
   */
  cout << "========================================================" << endl;
}

void
set_sols_size (size_t numSols) {
  // cout << numSols << ":" << intMaxSols << endl;
  if (numSols > intMaxSols) { intMaxSols=numSols; };
}

int
getLayer (IntArgId_T argId) {
  return argList[argId].layer;
};

template<typename A, typename B>
pair<B,A> flip_pair(const pair<A,B> &p) {
  return pair<B,A>(p.second, p.first);
};

template<typename A, typename B>
multimap<B,A> flip_map(const map<A,B> &src) {
  multimap<B,A> dst;
  transform(src.begin(), src.end(),
            inserter(dst, dst.begin()),
            flip_pair<A,B>);
  return dst;
};

bool
propagate_OUT(const IntArgId_T argToMakeIN,
              const set<IntArgId_T> & sccNodeList,
              const sol_type & condSolution,
              const sol_type & baseSolution,
              unordered_set<unordered_set<IntArgId_T>,setHash> & conflicts,
              size_t & thisSavedFromConflicts,
              sol_col_type & candSolutions);

template <typename Iter>
Iter
next_iter(Iter iter)
{
  return ++iter;
}

template <typename Iter, typename Cont>
bool
is_last(Iter iter, const Cont& cont)
{
  return (iter != cont.end()) && (next_iter(iter) == cont.end());
}

IntArgId_T
createIntArgId(ExtArgId_T nodeId) {
  return argList.size()+1;
}

bool
extArgIdExists (ExtArgId_T nodeId) {
  return intArgId.find(nodeId)!=intArgId.end();
}

IntArgId_T
getIntArgId (ExtArgId_T nodeId) {
  unordered_map<ExtArgId_T,IntArgId_T>::iterator idx = intArgId.find(nodeId);
  if (idx != intArgId.end()) {
    return idx->second;
  } else {
    return nullIntArgId;
  }
}

string
getExtArgId(IntArgId_T intArgId) {
  return argList[intArgId].extArgId;
};

void
get_IN_nodes (const sol_type & aSol,
              set<IntArgId_T> & nodesIn) {
  // Returns the arguments in aSol with value IN in the set nodesIn
  nodesIn.erase(nodesIn.begin(),nodesIn.end());
  //  cout << "About to insert nodes..." << endl;
  for (sol_type::const_iterator it=aSol.begin(); it!=aSol.end(); it++) {
    if (it->second==IN) {
      nodesIn.insert(it->first);
    };
  };
};

void
getArgsWithLabel (const sol_type & aSol,
                  const IntArgValue_T & label,
                  set<IntArgId_T> & nodes) {
  // Returns the arguments in aSol with a certain label in the set nodesIn
  nodes.clear();
  //  cout << "About to insert nodes..." << endl;
  for (sol_type::const_iterator it=aSol.begin(); it!=aSol.end(); it++) {
    if (it->second==label) {
      nodes.insert(it->first);
    };
  };
};


void
get_ext (const sol_type & aSol,
         unordered_set<IntArgId_T> & nodesIn) {
  // Returns the arguments in aSol with value IN in the set nodesIn
  nodesIn.erase(nodesIn.begin(),nodesIn.end());
  //  cout << "About to insert nodes..." << endl;
  for (sol_type::const_iterator it=aSol.begin(); it!=aSol.end(); it++) {
    if (it->second==IN) {
      nodesIn.insert(it->first);
    };
  };
};

void
get_IN_args (const sol_type & aSol,
             set<ExtArgId_T> & nodesIn) {
  // Returns the arguments in aSol with value IN in the set nodesIn
  nodesIn.erase(nodesIn.begin(),nodesIn.end());
  for (sol_type::const_iterator it=aSol.begin(); it!=aSol.end(); it++) {
    if (it->second==IN) {
      nodesIn.insert(getExtArgId(it->first));
    };
  };
};

void
get_partition (const sol_type & aSol,
               set<ExtArgId_T> & nodesIn,
               set<ExtArgId_T> & nodesOut,
               set<ExtArgId_T> & nodesUnd) {
  // Returns the arguments in aSol with value IN in the set nodesIn
  nodesIn.erase(nodesIn.begin(),nodesIn.end());
  nodesOut.erase(nodesOut.begin(),nodesOut.end());
  nodesUnd.erase(nodesUnd.begin(),nodesUnd.end());
  for (sol_type::const_iterator it=aSol.begin(); it!=aSol.end(); it++) {
    if (it->second==IN) {
      nodesIn.insert(getExtArgId(it->first));
    } else {
      if (it->second==OUT) {
        nodesOut.insert(getExtArgId(it->first));
      } else {
        nodesUnd.insert(getExtArgId(it->first));
      };
    };
  };
};

void
summarise_sol(const sol_type & aSol) {
  set<ExtArgId_T> in, out, und;
  get_partition(aSol,in,out,und);
  cout << " IN: ";
  for (auto it : in) {
    cout << it << " ";
  };
  cout << endl;
  cout << "OUT: ";
  for (auto it : out) {
    cout << it << " ";
  };
  cout << endl;
  cout << "UND: ";
  for (auto it : und) {
    cout << it << " ";
  };
  cout << endl;
}

void
get_crisp_values (const sol_type & solution,
                  sol_type & crispValues) {
  // Returns only the crisp values in solution
  crispValues.erase(crispValues.begin(),crispValues.end());
  for (sol_type::const_iterator it=solution.begin(); it!=solution.end(); it++) {
    if (it->second!=UND) {
      crispValues[it->first]=it->second;
    };
  };
};

void
wait () {
  cout << "Press ENTER to continue..." << flush;
  cin.ignore (std::numeric_limits<std::streamsize>::max (), '\n');
}

void
wait (string message) {
  cout << message << endl;
  cout << "Press ENTER to continue..." << flush;
  cin.ignore (std::numeric_limits<std::streamsize>::max (), '\n');
}

void
debug_wait () {
  if (debug) {
    cout << "Press ENTER to continue..." << flush;
    cin.ignore (std::numeric_limits<std::streamsize>::max (), '\n');
  };
}

void
debug_wait (string message) {
  if (debug) {
    cout << message << endl;
    cout << "Press ENTER to continue..." << flush;
    cin.ignore (std::numeric_limits<std::streamsize>::max (), '\n');
  };
}

bool
strict_str2int (char* str, int &result) {
  char* endptr;
  result = strtod (str, &endptr);
  return (!(*endptr));
}

bool
scc_level_comp(sccTuple * sccA, sccTuple * sccB) {
  return sccA->level < sccB->level;
};

void
display(string message) {
  cout << message;
};

void
display_node_list (const set<IntArgId_T> & nodeList) {
  for (set<IntArgId_T>::iterator it2 = nodeList.begin();
      it2 != nodeList.end(); it2++) {
    cout << getExtArgId(*it2) << " ";
  };
};

void
display_set (const unordered_set<ExtArgId_T> * extension) {
  cout << "[";
  for (unordered_set<ExtArgId_T>::const_iterator it=extension->begin();
      it!=extension->end(); it++) {
    cout << (*it);
    if (next(it,1)!=extension->end()) {
      cout << ",";
    };
  };
  cout << "]";
};

void
display_set (const set<IntArgId_T> & extension) {
  cout << "[";
  for (set<IntArgId_T>::const_iterator it=extension.begin();
      it!=extension.end(); it++) {
    cout << getExtArgId(*it);
    if (next(it,1)!=extension.end()) {
      cout << ",";
    };
  };
  cout << "]";
};

void
debug_set (const set<IntArgId_T> & extension) {
  for (set<IntArgId_T>::const_iterator it=extension.begin();
      it!=extension.end(); it++) {
    bugstr << getExtArgId(*it);
    if (next(it,1)!=extension.end()) {
      bugstr << ",";
    };
  };
}

void
display_set (const unordered_set<IntArgId_T> & extension) {
  cout << "[";
  for (unordered_set<IntArgId_T>::const_iterator it=extension.begin();
      it!=extension.end(); it++) {
    cout << getExtArgId(*it);
    if (next(it,1)!=extension.end()) {
      cout << ",";
    };
  };
  cout << "]";
};

void
display_all_sets(const unordered_set<unordered_set<IntArgId_T>,setHash> & theSets) {
  cout << "[";
  unsigned int ctr=0;
  for (unordered_set<unordered_set<IntArgId_T>,setHash>::const_iterator oneset=theSets.begin();
       oneset!=theSets.end(); oneset++) {
    ctr++;
    display_set(*oneset);
    if (ctr < theSets.size()) {
      cout << ",";
    };
  };
  cout << "]";
};

void
display_one_solution (const sol_type & partialSol) {
  cout << "[ ";
  for (sol_type::const_iterator it=partialSol.begin();
      it!=partialSol.end(); it++) {
    cout << getExtArgId(it->first) << "=" << getArgLabel(it->second) << " ";
  };
  cout << "]";
};

void
debug_one_solution (const sol_type & partialSol) {
  bugstr << "[ ";
  for (map<IntArgId_T,IntArgValue_T>::const_iterator it=partialSol.begin();
      it!=partialSol.end(); it++) {
    bugstr << getExtArgId(it->first) << "=" << getArgLabel(it->second) << " ";
  };
  bugstr << "]";
};



void
display_all_solutions(sol_col_type & solutions) {
  cout << "[";
  for (sol_col_type::iterator thisSol=solutions.begin();
      thisSol!=solutions.end(); thisSol++) {
    display_one_solution(*thisSol);
    if (next_iter(thisSol)!=solutions.end()) {
      cout << ",";
    }
  };
  cout << "]";
};

void
display_one_extension (const sol_type & thisSol) {
  cout << "[";
  bool firstArg=true;
  for (sol_type::const_iterator it=thisSol.begin();
      it!=thisSol.end(); it++) {
    if (it->second==IN) {
      if (firstArg) {
        firstArg = false;
      }
      else {
        cout << ",";
      };
      cout << getExtArgId( it->first);
    };
  };
  cout << "]";
};

void
display_all_extensions(sol_col_type & solutions) {
  cout << "[";
  for (sol_col_type::iterator thisSol=solutions.begin();
      thisSol!=solutions.end(); thisSol++) {
    display_one_extension(*thisSol);
    if (next(thisSol)!=solutions.end()) {
      cout << ",";
    };
  };
  cout << "]";
};

void
display_usage() {
  cout << "Usage:   " << executableName << " [options]" << endl;
  cout << "Options: one of\n --formats: list supported file formats\n"
      << " --problems: list supported problems\n -p <problem> -f <file> "
      << "-fo <fileformat> [-a <argumenttocheck>]\n"
      << "Limits: Max number of args=" << maxIntArgId
      << endl;
};

void
get_extension(const shared_ptr<sol_type> thisSol,
              set<IntArgId_T> & result) {
  for (sol_type::const_iterator it=thisSol->begin();
      it!=thisSol->end(); it++) {
    if (it->second==IN) {
      result.insert(it->first);
    };
  };
};

bool
is_stable(sol_type thisSol) {
  sol_type::const_iterator it=thisSol.begin();
  bool stable = true;
  while (stable && it!=thisSol.end()) {
    if (it->second == UND) {
      stable = false;
    };
    it++;
  };
  return stable;
}

void
remove_non_stable(sol_col_type & partialSols) {
  sol_col_type::iterator solIt =
      partialSols.begin();
  while (solIt != partialSols.end()) {
    if (!is_stable(*solIt)) {
      solIt=partialSols.erase(solIt);
    } else {
      ++solIt;
    };
  };
};

void
set_scc_level(sccTuple * sccToSet,
              vector<sccTuple *> & sccs) {
  int thisParentLevel;
  if (sccToSet->levelFound==false) {
    if (sccToSet->myParentSCCs.size() > 0) {
      int maxTParentLevel=min_int, maxNTParentLevel=min_int;
      for (set<sccTuple *>::iterator it =
          sccToSet->myParentSCCs.begin(); it!=
              sccToSet->myParentSCCs.end(); it++) {
        if (!sccToSet->levelFound) {
          set_scc_level(*it,sccs);
        };
        thisParentLevel=(*it)->level;
        if ((*it)->isTrivial) {
          maxTParentLevel=max(maxTParentLevel,thisParentLevel);
        } else {
          maxNTParentLevel=max(maxNTParentLevel,thisParentLevel);
        };
        //maxParentLevel=max(maxParentlevel,thisParentLevel);
      };
      if (sccToSet->isTrivial) {
        if (maxNTParentLevel >= 0) {
          // This SCC has non-trivial parents
          sccToSet->level=max(maxNTParentLevel+1,maxTParentLevel);
        } else {
          // All parents are trivial
          sccToSet->level=maxTParentLevel;
        };
      } else {
        sccToSet->level=max(maxNTParentLevel,maxTParentLevel)+1;
      };
      sccToSet->levelFound=true;
    } else {
      sccToSet->level=0;
      sccToSet->levelFound=true;
    };
  };
};

void
set_scc_levels (vector<sccTuple *> & sccs) {
  for (vector<sccTuple *>::iterator sccPtr=sccs.begin(); sccPtr!=sccs.end(); sccPtr++) {
    if (!(*sccPtr)->levelFound) {
      set_scc_level(*sccPtr,sccs);
    };
  };
  sort(sccs.begin(), sccs.end(), scc_level_comp);
  int prevSCCLevel, layerIdx=0;
  // vector<sccTuple *> newsccs;
  vector<sccTuple *>::iterator it=sccs.begin();
  while (it!=sccs.end()) {
    prevSCCLevel=(*it)->level;
    sccTuple * trivialscc = nullptr;
    sccLayerTuple * thisLayer = new sccLayerTuple;
    if ((*it)->isTrivial) {
      argList[*(*it)->nodes.begin()].layer=layerIdx;

      // Initialise trivialscc
      trivialscc = new sccTuple;
      trivialscc->isTrivial = true;
      trivialscc->level=(*it)->level;
      trivialscc->levelFound=true;
      trivialscc->layer=layerIdx;
      (*it)->layer=layerIdx;

      for (set<IntArgId_T>::iterator it2=(*it)->nodes.begin();
          it2!=(*it)->nodes.end(); it2++) {
        trivialscc->nodes.insert(*it2);
        // Now set the layer of the nodes in this SCC:
        argList[*it2].layer=layerIdx;
      };
      for (set<sccTuple *>::iterator it2=(*it)->myParentSCCs.begin();
          it2!=(*it)->myParentSCCs.end(); it2++) {
        trivialscc->myParentSCCs.insert(*it2);
      };
      for (set<IntArgId_T>::iterator it2=(*it)->parents.begin(); it2!=(*it)->parents.end(); it2++) {
        trivialscc->parents.insert(*it2);
      };
    } else {
      (*it)->layer=layerIdx;

      // Now set the layer of the nodes in this SCC:
      for (set<IntArgId_T>::iterator it2=(*it)->nodes.begin();
          it2!=(*it)->nodes.end(); it2++) {
        argList[*it2].layer=layerIdx;
      };

      // newsccs.push_back(*it);
      thisLayer->nonTrivialSCCs.push_back(*it);
    };
    it++;
    if (it!=sccs.end()) {
      // More SCCs to process
      while ((it!=sccs.end()) && ((*it)->level == prevSCCLevel)) {
        if ((*it)->isTrivial) {
          if (trivialscc == NULL) {
            // trivialscc not yet initialised!
            trivialscc = new sccTuple;
          };

          // argList[*((*it)->nodes.begin())].layer=layerIdx;

          // Now set the layer of the nodes in this SCC:
          for (set<IntArgId_T>::iterator it2=(*it)->nodes.begin();
              it2!=(*it)->nodes.end(); it2++) {
            argList[*it2].layer=layerIdx;
          };

          (*it)->layer=layerIdx;
          trivialscc->isTrivial = true;
          trivialscc->level=(*it)->level;
          trivialscc->levelFound=true;
          trivialscc->layer=layerIdx;
          for (set<IntArgId_T>::iterator it2=(*it)->nodes.begin();
              it2!=(*it)->nodes.end(); it2++) {
            trivialscc->nodes.insert(*it2);
          };
          for (set<sccTuple *>::iterator it2=(*it)->myParentSCCs.begin();
              it2!=(*it)->myParentSCCs.end(); it2++) {
            trivialscc->myParentSCCs.insert(*it2);
          };
          for (set<IntArgId_T>::iterator it2=(*it)->parents.begin();
              it2!=(*it)->parents.end(); it2++) {
            trivialscc->parents.insert(*it2);
          };
        } else {
          (*it)->layer=layerIdx;
          for (set<IntArgId_T>::iterator it2=(*it)->nodes.begin();
              it2!=(*it)->nodes.end(); it2++) {

            // argList[*((*it)->nodes.begin())].layer=layerIdx;

            // Now set the layer of the nodes in this SCC:
            for (set<IntArgId_T>::iterator it3=(*it)->nodes.begin();
                it3!=(*it)->nodes.end(); it3++) {
              argList[*it3].layer=layerIdx;
            };

          };
          // newsccs.push_back(*it);
          thisLayer->nonTrivialSCCs.push_back(*it);
        };
        it++;
      };
    };
    if (trivialscc!=NULL) {
      // newsccs.push_back(trivialscc);
      thisLayer->trivialSCC = *trivialscc;
    };
    sccLayers.push_back(thisLayer);
    layerIdx++;
  };

  if (decisionProblem) {
    unsigned int targetLayer = getLayer(intArgToFind);
    sccLayerTuple * aTuple = sccLayers[targetLayer];
    if (aTuple->trivialSCC.nodes.find(intArgToFind)==aTuple->trivialSCC.nodes.end()) {
      // The argument to find is not in the trivial SCC of its layer
      // so it must be in one of the non-trivial SCCs.
      // We want to put its SCC at the front of the queue to
      // process it first.

      vector<sccTuple *>::iterator it2=aTuple->nonTrivialSCCs.begin();
      bool found = false;
      unsigned int pos = 0;
      while (it2!=aTuple->nonTrivialSCCs.end() && !found) {
        set<IntArgId_T>::iterator it3=(*it2)->nodes.begin();
        while (!found && it3!=(*it2)->nodes.end()) {
          found = *it3==intArgToFind;
          it3++;
        };
        if (found) {
          if (pos > 0) {
            // Doing the magic:
            iter_swap(aTuple->nonTrivialSCCs.begin(),it2);
          }; // else: SCC is unique in this layer. Nothing to swap.

          //  wait();
        } else {
          it2++;
          pos++;
        };
      };
    }; // else: Argument to find is in trivial SCC so it will be processed
    //       first anyway. Nothing to swap.
  };
  // NO LONGER NEEDED (*sccs)=(*newsccs);
};

void
collect_layer_nodes(int layerIdx,
                    unordered_set<IntArgId_T> * layerNodeList) {

  layerNodeList->erase(layerNodeList->begin(),layerNodeList->end());
  if (sccLayers[layerIdx]->trivialSCC.nodes.size() > 0) {
    for (set<IntArgId_T>::iterator it=sccLayers[layerIdx]->trivialSCC.nodes.begin();
        it!=sccLayers[layerIdx]->trivialSCC.nodes.end(); it++) {
      layerNodeList->insert(*it);
    };
  };
  // Check Non-Trivial SCC:
  vector<sccTuple *>::iterator ntsccIt=sccLayers[layerIdx]->nonTrivialSCCs.begin();
  while (ntsccIt!=sccLayers[layerIdx]->nonTrivialSCCs.end()) {
    for (set<IntArgId_T>::iterator it=(*ntsccIt)->nodes.begin();
        it!=(*ntsccIt)->nodes.end(); it++) {
      layerNodeList->insert(*it);
    };
    ntsccIt++;
  };
};

int
total_unds (sol_type * partialSol) {
  int tot=0;
  for (sol_type::iterator it=partialSol->begin();
      it!=partialSol->end(); it++) {
    if (it->second==UND) { tot++; };
  };
  return tot;
};

bool
self_attacks(IntArgId_T nodeId) {
  return find(argList[nodeId].attsOut.begin(),argList[nodeId].attsOut.end(),nodeId)!=
      argList[nodeId].attsOut.end();
};

template<typename T>
bool
first_includes_or_equals_second(const T & first,
                                const T & second) {
  // cout << "Checking whether "; display_set(first); cout << " includes or is equal to "; display_set(second); cout << ": ";
  bool includes=first.size() >= second.size();
  typename T::const_iterator it=second.begin();
  while (includes && (it!=second.end())) {
    includes=(first.find(*it)!=first.end());
    it++;
  };
  // (includes ? cout << "Yes." << endl : cout << "No." << endl);
  return includes;
}

bool
first_strictly_includes_second(set<IntArgId_T> & first, set<IntArgId_T> & second) {

  bool strictlyIncludes=first.size() > second.size();
  set<IntArgId_T>::iterator it=second.begin();
  /*
  cout << "Checking: " << (it!=second.end()) << endl;
  cout << "Checking size: " << second.size() << endl;
  cout << "Actual set: "; display_set(second); cout << endl;
   */
  while (strictlyIncludes && (it!=second.end())) {
    //    cout << "Looking for " << getExtArgId(*it) << endl;
    strictlyIncludes=(first.find(*it)!=first.end());
    it++;
  };
  //  cout << "Returning " << strictlyIncludes << endl;
  return strictlyIncludes;
};

inline int
factorial(int x) {
  return (x == 1 ? x : x * factorial(x - 1));
}

void
getNewPossINs (const set<IntArgId_T> & sccNodes,
               const sol_type & SCCSol,
               const set<IntArgId_T> & old_poss_ins,
               set<IntArgId_T> & new_poss_ins) {
  for (auto node : old_poss_ins) {
    if (SCCSol.find(node)==SCCSol.end()) {
      new_poss_ins.insert(node);
    };
  };
};

void
make_sol_partial (const set<IntArgId_T> & sccNodes,
                  const sol_type & condSol,
                  sol_type & sccSol,
                  set<IntArgId_T> & poss_ins) {

  /*
    poss_ins:  UND nodes that do not self-attack and are not attacked by an
               external undecided node.
    condSol: a conditioning solution to nodes in previous layers
    SCCSol: an admissible solution to this SCC
   */
  poss_ins.erase(poss_ins.begin(),poss_ins.end());
  for (set<IntArgId_T>::iterator it=sccNodes.begin(); it!=sccNodes.end(); it++) {
    if (sccSol.at(*it)==UND) {
      // cout << "Looking at " << getExtArgId(*it) << endl;
      // Grounding this SCC with the values from previous layers resulted in the value UND
      if (!self_attacks(*it)) {
        // As this node does not self-attack, it could possibly be IN
        bool foundExtUndAtt=false;
        vector<IntArgId_T>::iterator attIt = argList[*it].attsIn.begin();
        while ((attIt != argList[*it].attsIn.end()) && !foundExtUndAtt) {
          if ((sccNodes.find(*attIt))==(sccNodes.end())) {
            // This attacker is NOT in this SCC, therefore it is external
            foundExtUndAtt=condSol.at(*attIt)==UND;
          };
          attIt++;
        };
        if (!foundExtUndAtt) {
          // This node has no undecided external attackers.
          // So indeed it could be IN.
          poss_ins.insert(*it);
          sccSol.erase(*it); // Node may be IN, OUT OR UND
        };
      } else {
        // Remove this UND assignment
        // cout << "Node " << getExtArgId(*it) << " attacks itself, leaving it in partial solution." << endl;
      };
      ; // else: node attacks itself
    };
  };
};

void
get_partial_sol (const set<IntArgId_T> & sccNodes,
                 const sol_type & condSol,
                 const sol_type & initSol,
                 sol_type & partSol) {

  /*
    poss_ins:  UND nodes that do not self-attack and are not attacked by an
               external undecided node.
    condSol: a conditioning solution to nodes in previous layers
    initSol: an admissible solution to this SCC
    partSol: a solution where all values IN, OUT and UND are
             conditioned by condSol and the nodes with label
	     BLANK can be IN in an extension
   */
  partSol=initSol;
  for (auto node : sccNodes) {
    // cout << "Checking " << getExtArgId(node) << endl;
    if (initSol.at(node)==UND) {
      // cout << "Looking at " << getExtArgId(node) << endl;
      // Grounding this SCC with the values from previous layers resulted in the value UND
      if (!self_attacks(node)) {
        // cout << getExtArgId(node) << " does not attack itself." << endl;
        // As this node does not self-attack, it could possibly be IN
        bool foundExtUndAtt=false;
        for (auto attacker : argList[node].attsIn) {
          if ((sccNodes.find(attacker))==(sccNodes.end())) {
            // This attacker is NOT in this SCC, therefore it is external
            if (condSol.at(attacker)==UND) {
              foundExtUndAtt=true;
              break;
            };
          };
        };
        if (!foundExtUndAtt) {
          // This node has no undecided external attackers.
          // So indeed it could be IN.
          // cout << getExtArgId(node) << "--> OK!!!" << endl;
          partSol[node]=BLANK; // Node may be IN, OUT OR UND
        };
      }; // Node attacks itself. Can't be IN.
    };
  };
};


void
getPurePossINs (const set<IntArgId_T> & sccNodes,
                const sol_type & condSol,
                const sol_type & initSol,
                unordered_set<IntArgId_T> old_poss_ins,
                unordered_set<IntArgId_T> & new_poss_ins) {

  // Gets an SCC, a conditioning solution, and a initial
  // solution to the SCC and returns the nodes in old_poss_ins
  // that can still be IN
  poss_in_timer.resume();
  unordered_set<IntArgId_T> tmp_poss_ins;
  for (auto node : old_poss_ins) {
    if (initSol.at(node)==UND) {
      if (!self_attacks(node)) {
        // As this node does not self-attack, it could possibly be IN
        bool foundExtUndAtt=false;
        for (auto attacker : argList[node].attsIn) {
          if ((sccNodes.find(attacker))==(sccNodes.end())) {
            // This attacker is NOT in this SCC, therefore it is external
            if (condSol.at(attacker)==UND) {
              foundExtUndAtt = true;
              break;
            };
          };
        };
        if (!foundExtUndAtt) {
          // This node has no undecided external attackers.
          // So indeed it could be IN.
          tmp_poss_ins.insert(node);
        };
      }; // Node attacks itself. Cannot be IN.
    };
  };
  new_poss_ins=tmp_poss_ins;
  poss_in_timer.pause();
};


bool
includesOrIsEqualToOneOf (sol_type baseSolution,
                          sol_col_type & candSolutions) {

  set<IntArgId_T> oneExt;
  set<IntArgId_T> thisCandExt;
  // Returns in oneExt the nodes in proposedSol with value IN
  get_IN_nodes(baseSolution,oneExt);
  bool propSolContained = false;
  // thisCandExt holds the set of IN nodes of a
  // proposed candidate numerical solution
  sol_col_type::iterator solIt=candSolutions.begin();
  while (!propSolContained && (solIt!=candSolutions.end())) {
    get_IN_nodes((*solIt),thisCandExt);
    if (thisCandExt.size() > 0) {
      propSolContained=first_includes_or_equals_second(thisCandExt,oneExt);
    } else {
      propSolContained = false;
    }
    // True if the candidate extension includes
    // or is equal to the proposed extension
    // Used to be includes or is equal
    solIt++;
  };
  return propSolContained;
};

bool
strictlyContainedInOneOf (const sol_type & baseSolution,
                          const sol_col_type & candSolutions) {

  set<IntArgId_T> oneExt, thisCandExt;
  // Returns in oneExt the nodes in proposedSol with value IN
  get_IN_nodes(baseSolution,oneExt);
  bool propSolContained = false;
  // thisCandExt holds the set of IN nodes of a
  // proposed candidate numerical solution
  sol_col_type::const_iterator solIt=candSolutions.begin();
  while (!propSolContained && (solIt!=candSolutions.end())) {
    get_IN_nodes((*solIt),thisCandExt);
    if (thisCandExt.size() > 0) {
      propSolContained=first_strictly_includes_second(thisCandExt,oneExt);
    } else {
      propSolContained = false;
    }
    // True if the candidate extension includes
    // or is equal to the proposed extension
    // Used to be includes or is equal
    solIt++;
  };
  return propSolContained;
};

bool
equalOrIncludedInOneOf (const sol_type & baseSolution,
                        const sol_col_type & candSolutions) {

  set<IntArgId_T>  oneExt, thisCandExt;
  // Returns in oneExt the nodes in proposedSol with value IN
  get_IN_nodes(baseSolution,oneExt);
  //  bool oldDebug=debug;
  //  debug = true;
  bool found = false;
  // thisCandExt holds the set of IN nodes of a
  // proposed candidate numerical solution

  sol_col_type::const_iterator solIt=candSolutions.begin();
  while (!found && (solIt!=candSolutions.end())) {
    get_IN_nodes((*solIt),thisCandExt);
    if (thisCandExt.size() > 0) {
      found=first_includes_or_equals_second(thisCandExt,oneExt);
    } else {
      found = false;
    }
    // True if the IN nodes in baseSolution are the
    // same as in one of the solutions in candSolutions
    solIt++;
  };
  //  debug=oldDebug;
  return found;
};

bool
equalOrIncludedInOneOf (unordered_set<IntArgId_T> & oneExt,
                        unordered_set<unordered_set<IntArgId_T>,setHash> & someExts) {


  // cout << "Checking whether "; display_set(oneExt);
  // cout << " is equal or is included in one of ";
  // for (auto it : someExts) {
  //   display_set(it); cout << " ";
  // }
  // cout << endl;
  // Returns in oneExt the nodes in proposedSol with value IN
  bool found = false;
  unordered_set<unordered_set<IntArgId_T>,setHash>::iterator solIt=someExts.begin();
  while (!found && (solIt!=someExts.end())) {
    if (solIt->size() > 0) {
      found=first_includes_or_equals_second<unordered_set<IntArgId_T>>(*solIt,oneExt);
    } else {
      found = false;
    }
    // True if the IN nodes in baseSolution are the
    // same as in one of the solutions in someExts
    solIt++;
  };
  //  debug=oldDebug;
  (found ? cout << "yes" << endl : cout << "no" << endl);
  return found;
};

bool
includesOrIsEqualToOneOf (unordered_set<IntArgId_T> & oneExt,
                          unordered_set<unordered_set<IntArgId_T>,setHash> & someExts) {

  // Returns in oneExt the nodes in proposedSol with value IN
  /*
  cout << "Checking whether "; display_set(oneExt);
  cout << " includes or is equal to one of ";
  for (auto it : someExts) {
    display_set(it); cout << " ";
  }
  cout << endl;
   */
  bool propSolContains = false;
  // thisCandExt holds the set of IN nodes of a
  // proposed candidate numerical solution
  unordered_set<unordered_set<IntArgId_T>,setHash>::iterator solIt=someExts.begin();
  while (!propSolContains && (solIt!=someExts.end())) {
    if (solIt->size() > 0) {
      propSolContains=first_includes_or_equals_second<unordered_set<IntArgId_T>>(oneExt,*solIt);
    } else {
      propSolContains = false;
    }
    // True if the candidate extension includes
    // or is equal to the proposed extension
    // Used to be includes or is equal
    solIt++;
  };
  return propSolContains;
};

bool
equalToOneOf (const sol_type baseSolution,
              const sol_col_type & candSolutions) {

  set<IntArgId_T>  oneExt, thisCandExt;
  // Returns in oneExt the nodes in proposedSol with value IN
  get_IN_nodes(baseSolution,oneExt);
  //  bool oldDebug=debug;
  //  debug = true;
  bool found = false;
  // thisCandExt holds the set of IN nodes of a
  // proposed candidate numerical solution
  sol_col_type::const_iterator solIt=candSolutions.begin();
  while (!found && (solIt!=candSolutions.end())) {
    get_IN_nodes((*solIt),thisCandExt);
    if (thisCandExt.size() > 0) {
      found=thisCandExt==oneExt;
    } else {
      found = false;
    }
    // True if the IN nodes in baseSolution are the
    // same as in one of the solutions in candSolutions
    solIt++;
  };
  //  debug=oldDebug;
  return found;
};

bool
equalToOneOf (unordered_set<IntArgId_T> & oneExt,
              unordered_set<unordered_set<IntArgId_T>,setHash> & candExts) {

  unordered_set<unordered_set<IntArgId_T>,setHash>::iterator thisCandExt = candExts.begin();
  // Returns in oneExt the nodes in proposedSol with value IN
  bool found = false;
  // thisCandExt holds one of the candExts
  set<IntArgId_T> ext;
  while (!found && (thisCandExt != candExts.end())) {
    found=(*thisCandExt)==oneExt;
    // ext = (*thisCandExt);
    // cout << "Comparing existing extension "; display_node_list(*thisCandExt);
    // cout << " with proposed extension ";
    // display_node_list(*oneExt); cout << endl;
    thisCandExt++;
  };
  return found;
};

bool
equalOrIncludedInOneOfExts (set<IntArgId_T> * oneExt,
                            set<set<IntArgId_T> > * candExts) {

  set<set<IntArgId_T> >::iterator thisCandExt = candExts->begin();
  // Returns in oneExt the nodes in proposedSol with value IN
  bool found = false;
  // thisCandExt holds one of the candExts
  set<IntArgId_T> ext1, ext2;
  while (!found && (thisCandExt != candExts->end())) {
    // cout << "Existing extension "; display_node_list(*thisCandExt);
    ext1 = (*thisCandExt);
    ext2 = (*oneExt);
    found=first_includes_or_equals_second(ext1,ext2);
    // (found ? cout << " includes or equals " : cout << " does not include or is not equal to ");
    // display_node_list(*oneExt); cout << endl;
    thisCandExt++;
  };
  return found;
};

void
removeStrictlyIncludedExtensions(const sol_type & baseSolution,
                                 sol_col_type & candSolutions) {

  set<IntArgId_T>  oneExt, thisCandExt;
  // Returns in oneExt the nodes in proposedSol with value IN
  get_IN_nodes(baseSolution,oneExt);

  sol_col_type::iterator it=candSolutions.begin();
  while (it!=candSolutions.end()) {
    get_IN_nodes(*it,thisCandExt);
    if (first_strictly_includes_second(oneExt,thisCandExt)) {
      // OPTIMISE:
      // Check if oneExt >= thisCandExt. If yes, remove thisCandExt.
      // Afterwards there is no need to check whether
      // oneExt already in preLabellings. Just insert it.

      // Delete this extension (it) from candidate labellings
      it=candSolutions.erase(it);
      debug_wait();
    } else {
      ++it; // thisCandExt NOT strictly included in the proposed extension
      // oneExt, leave it as a candidate preferred extension
    };
  };
  // Removal completed
};

bool
propagate_IN(const IntArgId_T argToMakeIN,
             const set<IntArgId_T> & sccNodes,
             const sol_type & condSol,
             const sol_type & initSol,
             sol_type & endSol) {

  if (initSol.at(argToMakeIN) != IN) {
    if (initSol.at(argToMakeIN)==BLANK) {
      // cout << "Attempting to label " << getExtArgId(argToMakeIN) << " IN" << endl;
      bool compatible = true;
      set<IntArgId_T> tocheck, changed;
      sol_type workSol = initSol;
      workSol[argToMakeIN]=IN;
      // Iterate through the nodes in scc that are attacked by argToMakeIN and
      // make them all OUT
      for (auto attacked : argList[argToMakeIN].attsOut) {
        if (sccNodes.find(attacked)!=sccNodes.end()) {
          // This attacked node is in the SCC
          // cout << "Checking attacked node " << getExtArgId(attacked) << ". ";
          if (workSol.at(attacked)!=IN) {
            if (workSol.at(attacked)!=OUT) {
              workSol[attacked]=OUT;
              // This node has changed labels, so we need to check it later
              changed.insert(attacked);
              //         cout << "Setting its new label to OUT" << endl;
            }; // else: nothing to do!
          } else {
            if (workSol.at(attacked)==IN) {
              // cout << "It was already IN. Can't change it to OUT." << endl;
              // This attacked node was already marked as IN
              // This assignment is not compatible
              compatible = false;
              break;
            }; // else: already OUT, nothing to do.
          };
        }; // Attacked node is outside: Not relevant to this solution.
      };
      /*
	cout << "Labelled all nodes attacked by "<< getExtArgId(argToMakeIN)<< " OUT" << endl;
	display_one_solution(workSol); cout  << endl;
	(compatible ? cout << "Proceeding..." << endl : cout << "Can't continue!" << endl);
       */
      if (compatible) {
        // cout << "The nodes: ( ";
        // for (auto node : changed) {
        //   cout << getExtArgId(node) << " ";
        // }
        // cout << ") changed labels to OUT." << endl;
        for (auto new_out : changed) {
          // cout << getExtArgId(new_out) << " attacks ";
          for (auto attacked : argList[new_out].attsOut) {
            // cout << getExtArgId(attacked) << " ";
            if (getLayer(new_out)==getLayer(attacked)) {
              tocheck.insert(attacked);
            }; // else: attacked node is outside SCC. Skipping...
          };
          // cout << endl;
        };
        sol_type nextSol=workSol;
        vector<IntArgId_T>::iterator it;
        IntArgValue_T thisAttValue;
        IntArgId_T candIN;
        while ((tocheck.size() > 0) && compatible) {
          candIN=*tocheck.begin();
          // cout << "Checking " << getExtArgId(candIN) << "." << endl;
          IntArgValue_T maxatt = OUT;
          // Get the maximum value of the attackers of this node
          thisAttValue=UND;
          for (auto attacker : argList[candIN].attsIn) {
            // cout << "  attacked by " << getExtArgId(attacker) << " with label ";
            if (getLayer(attacker) == getLayer(candIN)) {
              if (workSol.at(attacker)==BLANK) {
                thisAttValue=UND;
              } else {
                thisAttValue = workSol.at(attacker);
              };
              // cout << getArgLabel(thisAttValue) << endl;
            } else {
              thisAttValue = condSol.at(attacker);
              // cout << getArgLabel(thisAttValue) << endl;
            };
            maxatt=(maxatt > thisAttValue) ? maxatt : thisAttValue;
            if (maxatt > OUT) {
              // cout << "EARLY EXIT!" << endl;
              // candIN cannot be IN. Nothing to do!
              break;
            };
          };
          // Check whether we have the correct value for this node
          if (maxatt == OUT) {
            // workSol[candIN]=IN; // NOT NEEDED
            /*
	      cout << "All attackers of " << getExtArgId(candIN) <<
	      " are OUT. Trying to propagate IN from it." << endl;
             */
            compatible = propagate_IN(candIN,
                                      sccNodes,
                                      condSol,
                                      workSol,
                                      nextSol);
            workSol=nextSol;

          }; // else: node has undefined attacker
          tocheck.erase(tocheck.begin());
        };
        if (compatible) {
          endSol = workSol;
        };
        /*
	  if (compatible) {
	  cout << "Successful propagation: "; display_one_solution(endSol); cout << endl;
	  } else {
	  cout << "Failure!" << endl;
	  };
         */
      }; // else: this solution is not feasible
      return compatible;
    } else {
      return false;
    };
  } else  {
    // node was already IN. Nothing to do!
    endSol=initSol;
    return true;
  };
};

bool
propagate_forwards(const IntArgId_T argToMakeIN,
                   const set<IntArgId_T> & sccNodes,
                   const sol_type & condSol,
                   const sol_type & initSol,
                   const set<IntArgId_T> & poss_ins,
                   set<IntArgId_T> & new_poss_ins,
                   sol_type & newSol) {

  // Assumes argToMakeIN can be IN.
  set<IntArgId_T> stage_one_poss_ins = poss_ins;
  stage_one_poss_ins.erase(argToMakeIN);
  vector<IntArgId_T> attackers;
  set<IntArgId_T> tocheck, changed;
  sol_type workingSol=initSol;
  workingSol[argToMakeIN]=IN;
  bool compatible = true;

  // cout << "propagateIN: "; display_one_solution(initSol); cout << endl;
  for (auto node : argList[argToMakeIN].attsIn) {
    if (sccNodes.find(node)!=sccNodes.end()) {
      if (workingSol[node]==IN) {
        compatible = false;
        break;
      } else {
        if (workingSol.at(node)==UND) {
          stage_one_poss_ins.erase(node);
          workingSol[node]=MUST_OUT;
        }
      }
    }
  }
  if (compatible) {
    // cout << "It was possible to deal with all incoming attacks." << endl;
    for (auto node : argList[argToMakeIN].attsOut) {
      // cout << "Processing " << getExtArgId(node) << "=" << getArgLabel(workingSol[node]) << endl;
      if (sccNodes.find(node)!=sccNodes.end()) {
        // This attacked node is in the SCC
        if (workingSol[node]==IN) {
          // This attacked node was already labelled IN
          // This assignment is not compatible
          compatible = false;
          break;
        } else {
          if ((workingSol[node]==UND) || (workingSol[node]==MUST_OUT)) {
            stage_one_poss_ins.erase(node);
            workingSol[node]=OUT;
            // This node has changed labels, so we need to check it later
            changed.insert(node);
          }; // else: label was already OUT, nothing to do
        };
      }; // else, irrelevant: attack going outside of the SCC.
    };
    // changed now contains nodes whose labels changed to OUT
    // They may require further propagation
    // cout << "All attacked processed: "; display_one_solution(workingSol); cout << endl;
    if (compatible) {
      // cout << "It was possible to deal with all direct outgoing attacks." << endl;
      for (auto node : changed) {
        for (auto target : argList[node].attsOut) {
          if (getLayer(node) == getLayer(target)) {
            if (stage_one_poss_ins.find(target)!=poss_ins.end()) {
              // Node could potentially be IN
              tocheck.insert(target);
            }; // else: value already set, can't become IN
          }; // else: attacked node is outside SCC. Skipping...
        };
      };
      if (!tocheck.empty()) {
        // Each node in the list toCheck whose attackers
        // are all OUT need to be labelled IN:
        sol_type nextSol;
        vector<IntArgId_T>::iterator it;
        IntArgValue_T thisAttValue;
        IntArgId_T nextToMakeIN;
        set<IntArgId_T> stage_two_poss_ins = stage_one_poss_ins;
        while ((tocheck.size() > 0) && compatible) {
          nextToMakeIN=*tocheck.begin();
          attackers = argList[nextToMakeIN].attsIn;
          it=attackers.begin();
          IntArgValue_T maxatt = OUT;
          // Get the maximum value of the attackers of this node
          for (auto att : attackers) {
            if (getLayer(att) == getLayer(nextToMakeIN)) {
              thisAttValue = workingSol.at(att);
            } else {
              thisAttValue = condSol.at(att);
            };
            maxatt=(maxatt >= thisAttValue) ? maxatt : thisAttValue;
          };
          if (maxatt == OUT) {
            // We now need to progate_IN from this node.
            stage_two_poss_ins.erase(nextToMakeIN);
            compatible = propagate_forwards(nextToMakeIN,
                                            sccNodes,
                                            condSol,
                                            workingSol,
                                            stage_two_poss_ins,
                                            stage_two_poss_ins,
                                            workingSol);
          }; // else: node has undefined attacker
          tocheck.erase(nextToMakeIN);
        };
        // cout << "Finished propgation: "; display_one_solution(nextSol); cout << endl;
        if (compatible) {
          newSol=workingSol;
          new_poss_ins=stage_two_poss_ins;
        };
      } else {
        newSol=workingSol;
      };
    };
  };
  return compatible;
};

IntArgId_T
getMustIN(const map<IntArgId_T,IntArgValue_T> & startLabel,
          const sol_type & condSol) {
  IntArgId_T result = nullIntArgId;
  map<IntArgId_T,IntArgValue_T>::const_iterator it=startLabel.begin();
  bool found = false;
  while (!found && (it!=startLabel.end())) {
    if (it->second==UND) {
      bool allAttsOut = true;
      vector<IntArgId_T>::iterator attIt=argList[it->first].attsIn.begin();
      while (allAttsOut && (attIt != argList[it->first].attsIn.end())) {
        if (getLayer(*attIt)==getLayer(it->first)) {
          allAttsOut = (startLabel.at(*attIt)==OUT);
        } else {
          allAttsOut = (condSol.at(*attIt)==OUT);
        };
        attIt++;
      }
      if (allAttsOut) {
        if (startLabel.at(it->first)!=IN) {
          found = true;
          result = it->first;
        };
      }
    };
    it++;
  }
  return result;
}

IntArgId_T
newgetMustIN(const sol_type & initSol, const sol_type & condSol) {
  IntArgId_T result = nullIntArgId;
  map<IntArgId_T,IntArgValue_T>::const_iterator it=initSol.begin();
  bool found = false;
  while (!found && (it!=initSol.end())) {
    if ((it->second==UND) || (it->second==BLANK)) {
      bool allAttsOut = true;
      vector<IntArgId_T>::iterator attIt=argList[it->first].attsIn.begin();
      while (allAttsOut && (attIt != argList[it->first].attsIn.end())) {
        if (getLayer(*attIt)==getLayer(it->first)) {
          allAttsOut = (initSol.at(*attIt)==OUT);
        } else {
          allAttsOut = (condSol.at(*attIt)==OUT);
        };
        attIt++;
      }
      if (allAttsOut) {
        if (initSol.at(it->first)!=IN) {
          found = true;
          result = it->first;
        };
      }
    };
    it++;
  }
  return result;

}

void dGR_Grounder (const set<IntArgId_T> & nodeList,
                   const sol_type & condSol,
                   sol_type & grSCCSol) {
  unordered_set<IntArgId_T> watchList, nextWatchList;
  nextWatchList.reserve(nodeList.size());
  watchList.reserve(nodeList.size());
  // grSCCSol.reserve(nodeList.size());
  sol_type vi;
  // vi.reserve(nodeList.size());
  for (auto node : nodeList) {
    watchList.insert(node);
    vi[node]=UND;
    grSCCSol[node]=UND;
  };
  IntArgValue_T thisAttVal, maxAttVal;
  bool newValues = true;
  timer t;
  t.reset(); t.resume();
  while (newValues) {
    newValues = false;
    // cout << "Watching nodes "; display_set(watchList); cout << endl;
    for (auto node : watchList) {
      bool end = false;
      // cout << getExtArgId(node) << "=";
      maxAttVal = OUT;
      vector<IntArgId_T>::iterator att = argList[node].attsIn.begin();
      while (!end && att!=argList[node].attsIn.end()) {
        if (nodeList.find(*att)!=nodeList.end()) {
          thisAttVal = vi[*att];
        } else {
          thisAttVal = condSol.at(*att);
        };
        maxAttVal=(thisAttVal > maxAttVal ? thisAttVal : maxAttVal);
        end = maxAttVal == IN;
        att++;
      };
      grSCCSol[node]=IN - maxAttVal;
      // cout << getArgLabel(grSCCSol[node]) << endl;
      if (grSCCSol[node]!=vi[node]) {
        newValues = true;
        for (auto att : argList[node].attsOut) {
          if (getLayer(att)==getLayer(node)) {
            nextWatchList.insert(att);
          };
        };
      };
    };
    vi=grSCCSol;
    watchList=nextWatchList;
  };
  t.pause();
  cout << t.milli_elapsed();
};

void
new_ground_scc(const set<IntArgId_T> & nodeList,
           const sol_type & condSol,
           sol_type & grSCCSol) {
  IntArgId_T selectedArg;
  grSCCSol.clear();
  // cout << "Cond sol: "; display_one_solution(condSol); cout << endl;
  for (auto node : nodeList) {
    for (auto att : argList[node].attsIn) {
      if (condSol.find(att)!=condSol.end()) {
        if (condSol.at(att)==IN) {
          grSCCSol[node]=OUT;
          break;
        } else {
          if (condSol.at(att)==UND) {
            grSCCSol[node]=UND;
          };
        }
      };
    };
    if (grSCCSol.find(node)==grSCCSol.end()) {
      // Initial node value not yet determined
      if (self_attacks(node)) {
        grSCCSol[node]=UND;
      } else {
        grSCCSol[node]=BLANK;
      }
    }
  };
  // cout << "Init sol: "; display_one_solution(grSCCSol); cout << endl;

  // display_one_solution(grSCCSol); cout << endl;
  selectedArg = newgetMustIN(grSCCSol,condSol);
  // display_one_solution(grSCCSol); cout << endl;
  while (selectedArg != nullIntArgId) {
    // cout << "Selected " << getExtArgId(selectedArg) << endl;
    grSCCSol[selectedArg]=IN;
    for (vector<IntArgId_T>::iterator it=argList[selectedArg].attsOut.begin();
        it!= argList[selectedArg].attsOut.end(); it++) {
      if (nodeList.find(*it)!=nodeList.end()) {
        grSCCSol[*it]=OUT;
      };
    };
    // display_one_solution(grSCCSol); cout << endl;
    selectedArg = newgetMustIN(grSCCSol,condSol);
  };
  // cout << "After prop: "; display_one_solution(grSCCSol); cout << endl;
  // wait();
}


void
ground_scc(const set<IntArgId_T> & nodeList,
           const sol_type & condSol,
           sol_type & grSCCSol) {
  IntArgId_T selectedArg;
  for (auto node : nodeList) {
    grSCCSol[node]=UND;
    for (auto att : argList[node].attsIn) {
      if (condSol.find(att)!=condSol.end()) {
        if (condSol.at(att)==IN) {
          grSCCSol[node]=OUT;
        };
      };
    };
  };
  // display_one_solution(grSCCSol); cout << endl;
  selectedArg = getMustIN(grSCCSol,condSol);
  // display_one_solution(grSCCSol); cout << endl;
  while (selectedArg != nullIntArgId) {
    // cout << "Selected " << getExtArgId(selectedArg) << endl;
    grSCCSol[selectedArg]=IN;
    for (vector<IntArgId_T>::iterator it=argList[selectedArg].attsOut.begin();
        it!= argList[selectedArg].attsOut.end(); it++) {
      if (nodeList.find(*it)!=nodeList.end()) {
        grSCCSol[*it]=OUT;
      };
    };
    // display_one_solution(grSCCSol); cout << endl;
    selectedArg = getMustIN(grSCCSol,condSol);
  };
  // wait();
}

void fastestSCCGrounder (const set<IntArgId_T> & nodeList,
                         const sol_type & condSol,
                         sol_type & grSCCSol) {

  // clock_t _start_time = clock();
  // cout << clock() - _start_time << endl;
  vector<unordered_set<IntArgId_T>> layers;
  unordered_set<IntArgId_T> currLayer;
  currLayer.reserve(nodeList.size());
  unordered_set<IntArgId_T> nextLayer;
  nextLayer.reserve(nodeList.size());
  for (auto node : nodeList) {
    bool end = false;
    vector<IntArgId_T>::iterator att=argList[node].attsIn.begin();
    while (!end && (att != argList[node].attsIn.end())) {
      if (getLayer(*att) < getLayer(node)) {
        if (condSol.at(*att)==IN) {
          currLayer.insert(node);
          grSCCSol[node]=OUT;
          end=true;
        };
      };
      att++;
    };
  };
  // unordered_set<IntArgId_T> computed=currLayer;
  while (!currLayer.empty()) {
    nextLayer.clear();
    for (auto node : currLayer) {
      /// cout << "Analysing nodes attacked by " << getExtArgId(node) << endl;
      for (auto target : argList[node].attsOut) {
        /// cout << "Checking attacked node " << getExtArgId(target) << endl;
        if (getLayer(target)==getLayer(node)) {
          bool end = false;
          if (grSCCSol.find(target)==grSCCSol.end()) {
            /// cout << "Don't yet know value of " << getExtArgId(target) << endl;
            /// cout << "Checking attackers of " << getExtArgId(target) << endl;
            vector<IntArgId_T>::iterator att=argList[target].attsIn.begin();
            while (!end && (att != argList[target].attsIn.end())) {
              /// cout << getExtArgId(*att);
              if (nodeList.find(*att)!=nodeList.end()) {
                /// cout << " in SCC..." << endl;
                end = grSCCSol.find(*att)==grSCCSol.end();
                if (!end) {
                  /// cout << "Already know value of " << getExtArgId(*att) << endl;
                } else {
                  /// cout << "Do not know value of " << getExtArgId(*att) << endl;
                };
              } else {
                /// cout << " out of SCC." << endl;
              };
              att++;
            };
            if (!end) {
              // Can calculate value of target...
              IntArgValue_T thisAttVal, maxAttVal=OUT;
              for (auto att : argList[target].attsIn) {
                if (getLayer(att)==getLayer(target)) {
                  thisAttVal=grSCCSol[att];
                } else {
                  thisAttVal=condSol.at(att);
                };
                maxAttVal=((maxAttVal > thisAttVal) ? maxAttVal : thisAttVal);
              };
              /// cout << "Maximum attack value of " << getExtArgId(target) << " is " << getArgLabel(maxAttVal) << endl;
              grSCCSol[target]=IN - maxAttVal;
              nextLayer.insert(target);
              // computed.insert(target);
              if (grSCCSol[target]==IN) {
                for (auto att : argList[target].attsOut) {
                  if (getLayer(att)==getLayer(target)) {
                    grSCCSol[att]=OUT;
                    nextLayer.insert(att);
                    /// cout << "New value of " << getExtArgId(att) << " is "
                    /// << getArgLabel(grSCCSol[att]) << endl;
                    // computed.insert(att);
                  };
                };
              };
              /// cout << "New value of " << getExtArgId(target) << " is " << getArgLabel(grSCCSol[target]) << endl;
            };
          };
        };
      };
    };
    currLayer = nextLayer;
  };
  for (auto node : nodeList) {
    if (grSCCSol.find(node)==grSCCSol.end()) {
      grSCCSol[node]=UND;
    };
  };
};

/*
void
fastSCCGrounder(const set<IntArgId_T> & sccNodes,
		const sol_type & condSol,
		sol_type & grSCCSol) {

  // display_one_solution(condSol); cout << endl;
  unordered_set<IntArgId_T> toCheck;
  toCheck.reserve(sccNodes.size());
  // Label OUT all nodes attacked by an
  // external IN argument
  for (auto node : sccNodes) {
    // Label UND unless found IN attacker
    grSCCSol[node]=UND;
    for (auto att : argList[node].attsIn) {
      if (getLayer(att) < getLayer(node)) {
	if (condSol.at(att)==IN) {
	  grSCCSol[node]=OUT;
	  for (auto target : argList[node].attsOut) {
	    if (getLayer(target) == getLayer(node)) {
	      toCheck.insert(target);
	    };
	  };
	};
      };
    };
  };
  // cout << "Found list of nodes to check..." << endl;
  // Check if any node attacked by a node in
  // toCheck needs propagation:
  for (auto node : toCheck) {
    IntArgValue_T thisAttVal, maxAttVal = OUT;
    // cout << "Target " << getExtArgId(target) << " (" << getLayer(target) << "). Checking attacker ";
    for (auto att : argList[node].attsIn) {
      // cout << getExtArgId(att) << " (" << getLayer(att) << ") ";
      if (getLayer(att)==getLayer(node)) {
	thisAttVal=grSCCSol[att];
      } else {
	thisAttVal=condSol.at(att);
      };
      maxAttVal=((maxAttVal > thisAttVal) ? maxAttVal : thisAttVal);
    };
    // cout << endl;
    if (maxAttVal==OUT) {
      propagate_IN(node,sccNodes,condSol,grSCCSol,grSCCSol);
    };
  };
}
 */
void
updateSols(const sol_type & aSol,
                 sol_col_type & someSolutions) {

  /* Receives a solution and a set of candidate solutions
   * and updates the candidate solutions as needed.
   *
   * There are three cases to consider:
   * The new solution is one of the candidate solutions: nothing to do
   * The new solution is strictly included in an existing candidate solution
   * - If the problem is CO: simply insert the new solution
   * - If the problem is PR: nothing to do
   * The new solution strictly contains one or more existing solutions
   * - If the problem is CO: insert new solution
   * - If the problem is PR: insert new solution and remove all
   *   other solutions that are strictly included in it
   */

  if (problem["semantics"].find("CO") != string::npos) {
    someSolutions.insert(aSol);
  } else {
    bool end = false;
    set<IntArgId_T> thisExt, newExt;
    get_IN_nodes(aSol,newExt);
    sol_col_type::iterator solIt=
        someSolutions.begin();
    while ((solIt != someSolutions.end()) && !end) {
      get_IN_nodes(*solIt,thisExt);
      if (thisExt == newExt) {
        end = true;
      } else {
        if (first_strictly_includes_second(thisExt,newExt)) {
          if ((problem["semantics"].find("PR") != string::npos) ||
              (problem["semantics"].find("ST") != string::npos)) {
            end = true; // Nothing else to do
          } else {
            solIt++;
          }
        } else {
          if (first_strictly_includes_second(newExt,thisExt)) {
            if ((problem["semantics"].find("PR") != string::npos) ||
                (problem["semantics"].find("ST") != string::npos)) {
              solIt=someSolutions.erase(solIt);
            } else {
              solIt++;
            }
          } else {
            solIt++;
          }
        }
      }
    };
    if (!end) {
      if (problem["semantics"].find("ST") != string::npos) {
        bool ok = true;
        sol_type::const_iterator it=aSol.begin();
        while (ok && (it!=aSol.end())) {
          ok = (it->second != UND);
          it++;
        };
        if (ok) {
          insTime.resume();
          someSolutions.insert(aSol);
          insTime.pause();
        };
      } else {
        insTime.resume();
        someSolutions.insert(aSol);
        insTime.pause();
      };
    };
  };
};

void
complete_solution(const sol_type & partSol,
                  sol_type & compSol) {
  compSol = partSol;
  for (auto sol_pair : partSol) {
    if (sol_pair.second==BLANK) {
      compSol[sol_pair.first]=UND;
    };
  };
}


void
updateConflicts (const unordered_set<IntArgId_T> & propExt,
                 unordered_set<unordered_set<IntArgId_T>,setHash> & conflicts) {
  if (useConflicts) {
    // cout << "Known conflicts: "; display_all_sets(conflicts); cout << endl;
    // cout << "New conflict: "; display_set(propExt); cout << endl;
    conflicts.insert(propExt);
    // cout << "New conflicts: "; display_all_sets(conflicts); cout << endl;
  }
}

bool
optimiseFromConflicts(const IntArgId_T & argToMakeIN,
                      const sol_type & baseSolution,
                      unordered_set<IntArgId_T> & propExt,
                      unordered_set<unordered_set<IntArgId_T>,setHash> & conflicts) {
  if (useConflicts) {
    propExt.clear();
    get_ext(baseSolution,propExt);
    propExt.insert(argToMakeIN);
    // cout << "Conflict? ";
    // display_set(propExt); cout << endl;
    // cout << "Knowledge: "; display_all_sets(conflicts); cout << endl;
    return (conflicts.find(propExt)==conflicts.end());
  } else {
    return true;
  }
}


bool
makeArgIN (const IntArgId_T argToMakeIN,
           const set<IntArgId_T> & sccNodes,
           const sol_type & condSol,
           const sol_type & initSol,
           unordered_set<unordered_set<IntArgId_T>,setHash> & conflicts,
           size_t & thisSavedFromConflicts,
           sol_col_type & theseSolutions) {

  /*
    INPUT:
    - The list of the nodes in the SCC
    - An UND argument to be labelled IN where the search for extensions start
    - A conditioning solution with values of nodes in preceding layers
    - An admissible initial assignment initSol, which has to be obeyed

    OUTPUT:
    - the result of all successful propagations in the array candSolutions
   */
  // cout << "Trying to label " << getExtArgId(argToMakeIN) << " IN." << endl;
  bool isLegal=false;
  if (initSol.at(argToMakeIN)!=IN) {
    // argToMakeIN not yet labelled IN.
    sol_type nextSol, workSol;
    workSol = initSol;
    /*
    cout << "Before calling propagating_IN from " << getExtArgId(argToMakeIN)
    	 << ": "; display_one_solution(workSol); cout << endl;
     */
     unordered_set<IntArgId_T> propExt;
    if (optimiseFromConflicts(argToMakeIN,workSol,propExt,conflicts)) {
      if (propagate_IN(argToMakeIN,sccNodes,condSol,workSol,nextSol)) {
	// First try to propagate the value IN forward
	// If successful, then we need to make sure all attackers
	// of argToMakeIN can be labelled OUT
	// cout << "Success propagating IN from " << getExtArgId(argToMakeIN) << ": ";
	// display_one_solution(nextSol); cout << endl;
	isLegal=propagate_OUT(argToMakeIN,
			      sccNodes,
			      condSol,
			      nextSol,
			      conflicts,
			      thisSavedFromConflicts,
			      theseSolutions);
      } else {
	// cout << "MAKE IN, INNER CONFLICT (" << getExtArgId(argToMakeIN) << "): ";
	// display_set(propExt); cout << endl;
	updateConflicts(propExt,conflicts);
	// IN propagation from argToMakeIN failed...
	// cout << "Propagation from " << getExtArgId(argToMakeIN) << " failed..." << endl;
	isLegal=false;
      };
    } else {
      isLegal = false;
      thisSavedFromConflicts++;
    };
  } else {
    isLegal = true;
    sol_col_type result;
    result.insert(initSol);
    theseSolutions=result;
  };
  return isLegal;
};

bool
propagate_OUT(const IntArgId_T argToMakeIN,
              const set<IntArgId_T> & sccNodes,
              const sol_type & condSol,
              const sol_type & initSol,
              unordered_set<unordered_set<IntArgId_T>,setHash> & conflicts,
              size_t & thisSavedFromConflicts,
              sol_col_type & candSolutions) {

  /*
   * INPUT:
   * argToMakeIN: the argument whose attackers need all to be labelled OUT
   * sccNodes: a list of the nodes in this SCC
   * condSol: a conditioning solution with the labels of the nodes in
   *          preceding layers
   * initSol: a label assignment, whose crisp values cannot be
   *          modified
   *
   * OUTPUT:
   * true/false depending on whether it is possible to legally label all
   * attackers of argToMakeIN OUT
   * candSolutions: all "expansions" of initSol that legally label
   * all attackers of argToMakeIN OUT
   *
   */
  stepCtr++;
  map<IntArgId_T,unsigned int> argsToMakeOUT;
  sol_type workSol=initSol;
  // Let us start constructing a new solution that labels OUT
  // all attackers of argToMakeIN if possible at all:

  bool compatible = true;
  for (auto attacker : argList[argToMakeIN].attsIn) {
    if (getLayer(attacker) == getLayer(argToMakeIN)) {
      // Attacker in the same layer (hence in the same scc)
      // Only compatible if the label is OUT
      if (initSol.at(attacker)!=IN) {
        if (initSol.at(attacker)!=OUT) {
          argsToMakeOUT[attacker]=0; // To be set later
        };
      } else {
        compatible = false;
        break;
      };
    } else {
      // Attacker in a previous layer. Check it is labelled OUT.
      if (condSol.at(attacker)!=OUT) {
        compatible = false;
        break;
      };
    };
  };

  // Now analyse whether at least one of the attackers of
  // each attacker in argsToMakeOUT can be labelled IN.
  // This has to be done after the check above, because
  // we want to exclude attackers that also need to be
  // labelled OUT (as done above).
  if (compatible) {
    unsigned int yCtr;
    map<IntArgId_T,set<IntArgId_T> > toLabelIn;
    for (auto arg_pair : argsToMakeOUT) {
      yCtr=0;
      // Counts the number of attackers of this attacker that
      // can be labelled IN in order to label it OUT.
      // If yCtr = 0, then this attacker cannot be legally labelled
      // OUT and therefore propagateOUT must fail.
      // We want to start with attackers with minimal
      // yCtr value later because these minimise possible
      // outcomes.
      set<IntArgId_T> IN_args;
      for (auto attacker : argList[arg_pair.first].attsIn) {
        // We only need to consider the attackers that have not yet
        // been considered in this branch of execution
        if (getLayer(attacker) == getLayer(argToMakeIN)) {
          if (initSol.at(attacker)==BLANK) {
            // This attacker's attacker is in this SCC
            // As long as it is not itself required to be labelled OUT
            // it can be labelled IN
            if (argsToMakeOUT.find(attacker) == argsToMakeOUT.end()) {
              yCtr++; // This attacker has at least one attacker that can
              // be labelled IN
              IN_args.insert(attacker);
            };  // This cannot be used to label argIt OUT
          };
        }; // else: in another layer, cannot be counted
      };
      if (yCtr == 0) {
        compatible = false;
        break;
        // Cannot find any attacker of this attacker that can
        // be labelled IN
      } else {
        argsToMakeOUT[arg_pair.first]=yCtr;
        toLabelIn[arg_pair.first]=IN_args; // toLabelIN contains the arguments
        // that can be labelled IN in order to
        // label arg_pair.first OUT
      };
    };
    // By now we know
    // 1) whether it is possible to label all of the
    //    attackers of argToMakeIN OUT
    // 2) which of the attackers of each of these attackers
    //    can be labelled IN
    // 3) and how many they are
    if (compatible) {
      sol_type compSol;
      if (argsToMakeOUT.size() > 0) {
        // We know any solution must have all of the nodes in
        // argsToMakeOUT labelled OUT, so we need to label at
        // least one of the attackers of these nodes IN.

        // Iterate through argsToMakeOUT and try to make them all OUT
        // Start with the one with the least number of attackers labelled
        // UND in this scc.

        // ordToLabelOut contains all arguments that need to be labelled
        // OUT in increasing order of the number of arguments that attack
        // them, so we can just iterate through the list until at least one
        // attacker of every argument in ordToLabelOut is labelled IN.

        multimap<unsigned int, IntArgId_T> ordToLabelOut = flip_map(argsToMakeOUT);

        set<IntArgId_T> tocheck;
        IntArgId_T bestArg;

        sol_col_type allSols;
        allSols.insert(workSol);
        unordered_set<IntArgId_T> propExt;
        bool ok = true;
        multimap<unsigned int,IntArgId_T>::iterator it=ordToLabelOut.begin();
        while (it!=ordToLabelOut.end() && ok) {
          bestArg=it->second;
          // Trying to make all attackers of argToMakeIN OUT, one by one, guided by bestArg
          // Each one has a set of possibilities in the array toLabelIn[bestArg]
          // At least one of these need to succeed.
          sol_col_type bestArgSols; // Holds all valid solutions up to bestArg
          for (auto attToMakeIn : toLabelIn[bestArg]) {
            // set<IntArgId_T>::iterator anIt=toLabelIn[bestArg].begin();
            //   anIt!=toLabelIn[bestArg].end(); anIt++) {
            // Loop through attackers of bestArg that can be labelled IN
            // attToMakeIn = *anIt;
            for (auto thisSol : allSols) {
                sol_col_type tmpArgSols;
                if (makeArgIN(attToMakeIn,
                                   sccNodes,
                                   condSol,
                                   thisSol,
                                   conflicts,
                                   thisSavedFromConflicts,
                                   tmpArgSols)) {
                  // It was possible to label attToMakeIn IN
                  // Add these solutions to bestArg's solutions
                  for (auto sol : tmpArgSols) {
                    bestArgSols.insert(sol);
                  };
                };
            };
          };
          if (bestArgSols.size() > 0) {
            // This means it was possible to label OUT attacker bestArg of argToMakeIN
            // bestArgSols now contain all accumulated solutions
            allSols=bestArgSols;
          } else {
            ok = false;
          }
          it++;
        };
        if (ok) {
          // allSols now contains all solutions that label all arguments in
          // ordToLabelOut OUT.
          candSolutions=allSols;
        };
        return ok;
      } else {
        // argToMakeIN was already legally labelled IN in initSol
        candSolutions.insert(initSol);
        return true;
      }
    } else {
      return false;
    };
  } else {
    return false;
  };
}

void
removeCheckedNodes (set<IntArgId_T> * poss_ins,
                    vector<sol_type > * candSolutions) {
  bool found;
  set<IntArgId_T>::iterator it_ins = poss_ins->begin();
  set<IntArgId_T>::iterator next_it;
  while (it_ins!=poss_ins->end()) {
    vector<sol_type >::const_iterator solIt=candSolutions->begin();
    found = false;
    while ((solIt!=candSolutions->end()) && (it_ins!=poss_ins->end()) && !found) {
      auto search = solIt->find(*it_ins);
      if (search->second==IN) {
        found = true;
      };
      solIt++;
    }
    next_it = it_ins;
    next_it++;
    if (found) {
      poss_ins->erase(*it_ins);
    };
    it_ins = next_it;
  }
}

bool
legallyOut(const IntArgId_T intArgId,
           const set<IntArgId_T> & sccNodeList,
           const sol_type & condSolution,
           const sol_type & aSolution) {
  // cout << "Checking whether " << getExtArgId(intArgId)
  //      << " is legally OUT in solution "; display_one_solution(aSolution); cout << endl;
  bool isLegal = false;
  vector<IntArgId_T>::iterator attId=argList[intArgId].attsIn.begin();
  while (!isLegal && attId!=argList[intArgId].attsIn.end()) {
    // Where is this attacker?
    if (sccNodeList.find(*attId) == sccNodeList.end()) {
      // Attacker outside SCC, legally OUT iff attacker is IN in condSolution
      // cout << "External attacker " << getExtArgId(*attId) << " of "
      // 	   << getExtArgId(intArgId) << " is labelled "
      // 	   << getArgLabel(condSolution->at(*attId)) << endl;
      isLegal = condSolution.at(*attId)==IN;
    } else {
      // cout << "Internal attacker " << getExtArgId(*attId) << " of "
      // 	   << getExtArgId(intArgId) << " is labelled "
      // 	   << getArgLabel(aSolution->at(*attId)) << endl;
      // Attacker in SCC, legally OUT if attacker is IN in aSolution
      isLegal = aSolution.at(*attId)==IN;
    };
    attId++;
  };
  return isLegal;
}

bool
legallyIn(const IntArgId_T intArgId,
          const set<IntArgId_T> & sccNodeList,
          const sol_type & condSolution,
          const sol_type & aSolution) {
  bool isLegal = true;
  vector<IntArgId_T>::iterator attId=argList[intArgId].attsIn.begin();
  while (isLegal && attId!=argList[intArgId].attsIn.end()) {
    // Where is this attacker?
    if (sccNodeList.find(*attId) == sccNodeList.end()) {
      // Attacker outside SCC, legally IN iff attacker is OUT in condSolution
      isLegal = condSolution.at(*attId)==OUT;
    } else {
      // Attacker in SCC, legally OUT if attacker is IN in aSolution
      isLegal = aSolution.at(*attId)==OUT;
    };
    attId++;
  };
  return isLegal;
}

bool
superIllegallyIn(const IntArgId_T intArgId,
                 const set<IntArgId_T> & sccNodeList,
                 const sol_type & condSolution,
                 const sol_type & aSolution) {
  bool superIllegal = false;
  vector<IntArgId_T>::iterator attId=argList[intArgId].attsIn.begin();
  while (!superIllegal && attId!=argList[intArgId].attsIn.end()) {
    // Where is this attacker?
    if (sccNodeList.find(*attId) == sccNodeList.end()) {
      // Attacker outside SCC, node is super illegally IN iff attacker is
      // IN or UND in condSolution (condSolution is legal by definition)
      superIllegal = (condSolution.at(*attId)==IN || condSolution.at(*attId)==UND);
    } else {
      // Attacker in SCC, super illegal if attacked by legally IN arg
      // or an argument that is UND
      if (aSolution.at(*attId)==UND ||
          legallyIn(*attId,sccNodeList,condSolution,aSolution)) {
        superIllegal = true;
      };
    };
    attId++;
  };
  return superIllegal;
}

void
print_knowledge(map<set<IntArgId_T>,vector<sol_type>> & learnt_propag) {
  cout << "Learnt clauses: " << endl;
  for (map<set<IntArgId_T>,vector<sol_type>>::iterator clauseIt=learnt_propag.begin();
      clauseIt!=learnt_propag.end(); clauseIt++) {
    display_set(clauseIt->first); cout << "-->";
    // display_all_solutions(clauseIt->second); cout << endl;
  };
};

unsigned int
getNumUnd(const IntArgId_T argId,
          const vector<IntArgId_T> & nodes,
          const sol_type & baseSolution) {
  unsigned int degree=0;
  // cout << "Checking for " << getExtArgId(argId) << ":" << getLayer(argId) << endl;
  for (auto it : nodes) {
    // cout << getExtArgId(it) << ":" << getLayer(it) << endl;
    if (getLayer(argId)==getLayer(it)) {
      // This edge is in the same SCC
      if (baseSolution.find(it)!=baseSolution.end()) {
        if (baseSolution.at(it) == UND) {
          degree++;
        };
      } else {
        degree++;
      }
    };
    // cout << getExtArgId(it) << "=" << getArgLabel(baseSolution.at(it)) << endl;
  };
  return degree;
};

unsigned int
getNumArgsWithLabel(const IntArgId_T argId,
                    const vector<IntArgId_T> & nodes,
                    const IntArgValue_T label,
                    const sol_type & baseSolution) {
  unsigned int degree=0;
  // cout << "Checking for " << getExtArgId(argId) << ":" << getLayer(argId) << endl;
  for (auto it : nodes) {
    // cout << getExtArgId(it) << ":" << getLayer(it) << endl;
    if (getLayer(argId)==getLayer(it)) {
      // This edge is in the same SCC
      if (baseSolution.find(it)!=baseSolution.end()) {
        if (baseSolution.at(it) == label) {
          degree++;
        };
      } else {
        degree++;
      }
    };
    // cout << getExtArgId(it) << "=" << getArgLabel(baseSolution.at(it)) << endl;
  };
  return degree;
};

unsigned int
degree(IntArgId_T argId) {
  return (argList[argId].attsIn.size()+argList[argId].attsOut.size());
};

IntArgId_T
selectBestArg(const sol_type & partSol) {
  unsigned int bestDegree = 0, thisDegree = 0;
  unordered_set<IntArgId_T> possINs;
  possINs.reserve(partSol.size());
  for (auto sol_pair : partSol) {
    if (sol_pair.second==BLANK) {
      possINs.insert(sol_pair.first);
    };
  };
  IntArgId_T bestArg = *possINs.begin();
  if (__policy != FIRST) {
    // cout << "Strategy is " << getPolicy(__policy) << endl;
    for (auto node : possINs) {
      //    cout << getExtArgId(it->first) << "=" << getArgLabel(it->second) << endl;
      if ((__policy == MAX_OUT) || (__policy == MIN_OUT)) {
        thisDegree = getNumArgsWithLabel(node,argList[node].attsOut,BLANK,partSol);
        if (__policy == MAX_OUT) {
          if (thisDegree>=bestDegree) {
            bestDegree=thisDegree;
            bestArg = node;
          };
          // cout << "Higher OUT degree found for " << getExtArgId(node) << "=" << degree << endl;
        } else {
          if (__policy == MIN_OUT) {
            if (thisDegree<=bestDegree) {
              bestDegree=thisDegree;
              bestArg = node;
              // cout << "Lower OUT degree found for " << getExtArgId(node) << "=" << degree << endl;
            };
          };
        };
      } else {
        if ((__policy == MAX_IN) || (__policy == MIN_IN)) {
          thisDegree = getNumArgsWithLabel(node,argList[node].attsIn,BLANK,partSol);
          if (__policy == MAX_IN) {
            if (thisDegree>=bestDegree) {
              bestDegree=thisDegree;
              bestArg = node;
              // cout << "Higher IN degree found for " << getExtArgId(node) << "=" << degree << endl;
            };
          } else {
            if (__policy == MIN_IN) {
              if (thisDegree<=bestDegree) {
                bestDegree=thisDegree;
                bestArg = node;
                // cout << "Lower IN degree found for " << getExtArgId(node) << "=" << degree << endl;
              };
            };
          };
        };
      };
    };
  };
  return bestArg;
}

bool
is_legal(const sol_type & aSol) {
  bool result = true;
  for (auto sol_pair : aSol) {
    if (sol_pair.second==MUST_OUT) {
      result = false;
      break;
    }
  }
  return result;
};

/*
IntArgId_T
getMustIN(const sol_type & startLabel,
          const set<IntArgId_T> & poss_ins) {
  IntArgId_T result = nullIntArgId;
  for (auto node : poss_ins) {
    bool ok = true;
    vector<IntArgId_T>::iterator attIt=argList[node].attsIn.begin();
    while (ok && (attIt != argList[node].attsIn.end())) {
      ok = ((startLabel.at(*attIt)==OUT) || (startLabel.at(*attIt)==MUST_OUT));
      attIt++;
    }
    if (ok) {
      result = node;
      break;
    }
  };
  return result;
}
*/

bool
is_hopeless(const sol_type & initSol,
            const set<IntArgId_T> & poss_ins) {
  set<IntArgId_T> mustOUTs;
  for (auto sol_pair : initSol) {
    if (sol_pair.second==MUST_OUT) {
      mustOUTs.insert(sol_pair.first);
    }
  }
  bool isHopeless = false;
  set<IntArgId_T>::iterator it=mustOUTs.begin();
  while (it!=mustOUTs.end() && !isHopeless) {
    vector<IntArgId_T>::iterator attIt=argList[*it].attsIn.begin();
    bool thisOk = false;
    while (!thisOk && (attIt!=argList[*it].attsIn.end())) {
      thisOk = (initSol.at(*attIt)==IN || poss_ins.find(*attIt)!=poss_ins.end());
      attIt++;
    };
    isHopeless = !thisOk;
    it++;
  };
  return isHopeless;
}

bool
is_admissible(const sol_type & initSol) {
  set<IntArgId_T> mustOUTs;
  for (auto sol_pair : initSol) {
    if (sol_pair.second==MUST_OUT) {
      mustOUTs.insert(sol_pair.first);
    }
  }
  if (mustOUTs.empty()) {
    debug_one_solution(initSol);
    bugstr << " is an admissible labelling." << endl;
    return true;
  } else {
    return false;
  }
};

bool
is_complete(const sol_type & aSolution) {
  if (is_admissible(aSolution)) {
    bool allOk = true;
    for(auto sol_pair : aSolution) {
      if (sol_pair.second == UND) {
        bool thisOk = false;
        vector<IntArgId_T>::iterator attIt=argList[sol_pair.first].attsIn.begin();
        while (!thisOk && (attIt!=argList[sol_pair.first].attsIn.end())) {
          thisOk=(aSolution.at(*attIt)==UND);
          attIt++;
        };
        if (!thisOk) { allOk=false; break; }
        allOk=thisOk;
      };
    };
    return allOk;
  } else {
    return false;
  }
};

bool
is_partial (const sol_type & partSol) {
  bool result = false;
  for (auto sol_pair : partSol) {
    if (sol_pair.second == BLANK) {
      result = true;
      break;
    };
  };
  return result;
};

void
findSCCSols (const set<IntArgId_T> & sccNodes,
                  const sol_type & condSol,
                  const sol_type & initSol,
                  sol_col_type & candSols,
                  unordered_set<unordered_set<IntArgId_T>,setHash> & conflicts,
                  size_t & thisSavedFromConflicts,
                  string prefix) {

  /*
   *  INPUT:
   *  - A list of the nodes in the SCC
   *  - Nodes whose values can possibly be IN
   *  - A conditioning solution with values of nodes in preceding layers
   *  - An admissible initial assignment initSol, which has to be obeyed
   *
   *  OUTPUT:
   *  - true, if propagation is successful and the result of propagation in
   *    the array equilArray
   *  - false, if propagation cannot be done successfully
   */


  sol_type workSol, mainSol, compSol;
  vector<IntArgId_T> attackers;
  IntArgId_T argToMakeIN;
  sol_col_type theseSolutions;
  unordered_set<IntArgId_T> propExt;
  numRecCalls++;
  mainSol=initSol;
  // cout << "Path:" << prefix << endl;
  while (is_partial(mainSol)) {
    // display_one_solution(mainSol); cout << endl;
   argToMakeIN = selectBestArg(mainSol);
    // if (getExtArgId(argToMakeIN)=="x") {
    //   cout << "Selected " << getExtArgId(argToMakeIN) << endl;
    //   wait();
    // };
    prefix = prefix + getExtArgId(argToMakeIN) + ":";
    // if (optimiseFromConflicts(
      workSol = mainSol;
      theseSolutions.clear();
      if (makeArgIN(argToMakeIN,
                    sccNodes,
                    condSol,
                    workSol,
                    conflicts,
                    thisSavedFromConflicts,
                    theseSolutions)) {
        for (auto thisSol : theseSolutions) {
          updateSols(thisSol,candSols);
          findSCCSols(sccNodes,
                      condSol,
                      thisSol,
                      candSols,
                      conflicts,
                      thisSavedFromConflicts,
                      prefix);
        };
        // else {
        //	if (getExtArgId(argToMakeIN)=="x") {
        //	  // Conflict learning below:
        //	  cout << "Can't make " << getExtArgId(argToMakeIN) << " IN!" << endl;
        //	  set<IntArgId_T> propExt;
        //	  getArgsWithLabel(mainSol,IN,propExt);
        //	  propExt.insert(argToMakeIN);
        //	  display_set(propExt);
        //	  cout << endl;
        //	};
        // // display_one_solution(workSol); cout << endl;
        // // cout << "=============================================================================" << endl;
        // // cout << "OUTER CONFLICT (" << getExtArgId(argToMakeIN) << "): ";
        // // display_set(propExt); cout << endl;
        // // updateConflicts(propExt,conflicts);
      };
      mainSol[argToMakeIN]=UND;
    // } else {
    //   cout << "OUTER AVOIDED (" << getExtArgId(argToMakeIN) << "): ";
    //   unordered_set<IntArgId_T> thisSet=propExt;
    //   propExt.insert(argToMakeIN);
    //   display_set(thisSet); cout << endl;
    //   // Saved one from conflict
    //   thisSavedFromConflicts++;
    //   mainSol[argToMakeIN]=UND;
    // };
  };
};


void
strongconnect (IntArgId_T nodeId,
               IntArgId_T parent,
               int * index,
               map<IntArgId_T, nodeTuple> * nodeIndex,
               stack<sccPair> * S,
               vector<sccTuple *> & sccs,
               map<IntArgId_T,sccTuple *> * sccMember) {
  (*nodeIndex)[nodeId].index = (*index);
  (*nodeIndex)[nodeId].lowindex = (*index);
  (*index)++;
  sccPair pair;
  pair.node = nodeId;
  pair.parent = parent;
  S->push (pair);
  (*nodeIndex)[nodeId].isRemoved = false;
  vector<IntArgId_T>::iterator it2 = argList[nodeId].attsOut.begin ();
  while (it2 != argList[nodeId].attsOut.end ()) {
    if ((*nodeIndex).find (*it2) == (*nodeIndex).end ()) {
      // cout << "IF" << endl;
      strongconnect (*it2, nodeId, index, nodeIndex, S, sccs, sccMember);
      (*nodeIndex)[nodeId].lowindex = min ((*nodeIndex)[nodeId].lowindex,
                                           (*nodeIndex)[*it2].lowindex);
    } else {
      // cout << "ELSE" << endl;
      if ((*nodeIndex)[*it2].isRemoved == false) {
        (*nodeIndex)[nodeId].lowindex = min ((*nodeIndex)[nodeId].lowindex,
                                             (*nodeIndex)[*it2].index);
      } else {
        (*sccMember)[*it2]->parents.insert(nodeId);
      };
    };
    it2++;
  };
  // cout << "Processed all nodes attacked by " << getExtArgId(nodeId) << endl;
  if ((*nodeIndex)[nodeId].lowindex == (*nodeIndex)[nodeId].index) {
    // Found new SCC.
    sccTuple * newscc = new sccTuple;
    newscc->levelFound=false;
    newscc->level=0;
    pair = S->top ();
    S->pop ();
    (*nodeIndex)[pair.node].isRemoved = true;
    newscc->nodes.insert (pair.node);
    (*sccMember)[pair.node]=newscc;

    if (pair.node == nodeId) {
      // This is a single node SCC
      // It is trivial if the node does not attack itself
      newscc->isTrivial=(find(argList[nodeId].attsIn.begin(),
                              argList[nodeId].attsIn.end(),
                              nodeId)==argList[nodeId].attsIn.end());
    } else {
      // There are multiple nodes in this SCC
      newscc->isTrivial = false;
      while (pair.node != nodeId) {
        pair = S->top ();
        S->pop ();
        (*nodeIndex)[pair.node].isRemoved = true;
        newscc->nodes.insert (pair.node);
        (*sccMember)[pair.node]=newscc;
      };
    };
    sccs.push_back (newscc);
  };
}

void
decompose_and_stratify () {
  vector<sccTuple *> sccs;
  map<IntArgId_T, sccTuple *> * sccMember = new  map<IntArgId_T, sccTuple *>;
  int index = 0;
  sccs.erase (sccs.begin(), sccs.end());
  map<IntArgId_T, nodeTuple> nodeIndex;
  stack<sccPair> S;
  for (unordered_map<IntArgId_T, ArgNode_T>::iterator idx=argList.begin(); idx!=argList.end(); idx++) {
    if (nodeIndex.find(idx->first) == nodeIndex.end ()) {
      strongconnect (idx->first,0,&index,&nodeIndex,&S,sccs,sccMember);
    };
  };
  // cout << "Finished main loop!" << endl;
  // We already know the attackers of every SCC.
  // Now we need to compute the attacking SCCs.
  // We need to insert the attacking SCCs here!

  for (vector<sccTuple *>::iterator it=sccs.begin(); it!=sccs.end(); it++) {
    for (set<IntArgId_T>::iterator it2=(*it)->nodes.begin(); it2!=(*it)->nodes.end(); it2++) {
      for (vector<IntArgId_T>::iterator it3=argList[*it2].attsIn.begin();
          it3!=argList[*it2].attsIn.end(); it3++) {
        if ((*sccMember)[*it3]!=(*it)) {
          // The attacker of this member is not in the SCC itself
          (*it)->myParentSCCs.insert((*sccMember)[*it3]);
        };
      };
    };
  };
  // Stratify:
  totSCCs = sccs.size();
  // cout << "Read to stratify..." << endl;
  set_scc_levels(sccs);
}

void
getSCCSol(const set<IntArgId_T> & sccNodes,
          const sol_type & grLayerSol,
          sol_type & grSCCSol) {
  // cout << "Grounded layer sol: "; display_one_solution(grLayerSol); cout << endl;
  for (set<IntArgId_T>::iterator it=sccNodes.begin(); it!=sccNodes.end(); it++) {
    grSCCSol[*it]=grLayerSol.at(*it);
  };
  // cout << "Grounded SCC sol: "; display_one_solution(grSCCSol); cout << endl;
};

IntArgId_T
getNumOfArgs(ifstream * infile) {

  bool endOfNodes = false;
  IntArgId_T curIntArgId = 0;
  char * pch;
  char pch_str[256];
  string inputStr, nodeID;
  while (!infile->eof() && !endOfNodes) {
    getline(*infile, inputStr);
    strcpy(pch_str, inputStr.c_str());
    pch = strtok(pch_str, " ,:");
    if (pch != NULL) {
      if (string(pch) != "#") {
        if ((curIntArgId + 1) < maxIntArgId) {
          curIntArgId++;
        };
        pch = strtok(NULL, " ,:");
        if (pch != NULL) {
          // Warning: ignoring remaining of line lineNum
        };
      }
      else {
        endOfNodes = true;
      };
    };
  };
  // Return to the beginning of file
  infile->clear();
  infile->seekg(0, ios::beg);
  return curIntArgId;
}

bool
readFile() {
  vector<IntArgId_T> attackers;
  char pch_str[256];
  char * pch;
  ifstream infile;
  bool endOfNodes, error;
  string inputStr, nodeID, sourceID, targetID;
  int lineNum;
  IntArgId_T curIntArgId;
  vector<IntArgId_T>::iterator it2;
  unordered_map<IntArgId_T, ExtArgId_T>::iterator intSourceIdPtr,
  intTargetIdPtr;
  map<IntArgId_T, ExtArgId_T>::iterator extArgIdPtr;
  infile.open(problem["filename"].c_str(), ifstream::in);
  if (infile) {
    totArgs = getNumOfArgs(&infile);
    if (totArgs <= maxIntArgId) {
      argList.reserve(totArgs);
      intArgId.reserve(totArgs);
      // Read Nodes
      lineNum = 0;
      error = false;
      endOfNodes = false;
      nodeID = "";
      ArgNode_T argNode;
      while (!infile.eof() && !error && !endOfNodes) {
        getline(infile, inputStr);
        lineNum++;
        strcpy(pch_str, inputStr.c_str());
        pch = strtok(pch_str, " ,:");
        if (pch != NULL) {
          if (string(pch) != "#") {
            nodeID = string(pch);
            if (!extArgIdExists(nodeID)) {
              // New node ID. Good to go.
              if (argList.size() < maxIntArgId) {
                curIntArgId = argList.size()+1;
              } else {
                cout << "Maximum number of arguments exceeded! Aborting." << endl;
                exit(0);
              };
              argNode.extArgId = nodeID;
              argNode.attsIn = attackers;
              argNode.attsOut = attackers;
              argList[curIntArgId]=argNode;
              intArgId[nodeID]=curIntArgId;
              attackers.erase(attackers.begin(), attackers.end());
            }; // else: Warning: node nodeID specified more than once! Ignoring.
            pch = strtok(NULL, " ,:");
            if (pch != NULL) {
              // Warning: ignoring remaining of line lineNum
            };
          }
          else {
            endOfNodes = true;
          };
        };
      };
      // Read Edges
      totEdges = 0;
      IntArgId_T srcIntArgId, trgIntArgId;
      while (!infile.eof() && !error) {
        getline(infile, inputStr);
        lineNum++;
        strcpy(pch_str, inputStr.c_str());
        pch = strtok(pch_str, " ,:");
        if (pch != NULL) {
          sourceID = string(pch);
          srcIntArgId = getIntArgId(sourceID);
          if (srcIntArgId != nullIntArgId) {
            pch = strtok(NULL, " ,:");
            if (pch != NULL) {
              targetID = string(pch);
              trgIntArgId = getIntArgId(targetID);
              if (trgIntArgId != nullIntArgId) {
                argList[srcIntArgId].attsOut.push_back(trgIntArgId);
                argList[trgIntArgId].attsIn.push_back(srcIntArgId);
                totEdges++;
              }
              else {
                cout << "Error in line " << lineNum
                    << " of input file. Target of attack"
                    << " in edge definition not found: "
                    << targetID << endl;
                error = true;
              };
            }
            else {
              error = true;
              cout << "Missing target of edge in line " << lineNum << endl;
            };
          }
          else {
            cout << "Error in line " << lineNum
                << " of input file. Source node "
                << getExtArgId( intSourceIdPtr->first)
                << " in edge definition not found!\n";
          };
        }; // else: read an empty line...
      };
      if (error) {
        cout << "Error scanning input file! " << endl;
      };
    } else {
      cout << "Maximum number of arguments of this solver is " << maxIntArgId << "." << endl;
      cout << "Capacity exceeded. Aborting!" << endl;
      error = true;
    };
  } else {
    cout << "Cannot open file \""
        << problem["filename"]
                   << "\"." << endl;
    error = true;
  };
  infile.close();
  return (!error);
}

bool
read_extension(string extStr, unordered_set<ExtArgId_T> * extension) {
  char pch_str[extStr.size()+1];
  char * pch;
  string nodeID;
  // if (extStr.size() > max_ext_length) {
  //   cout << "Houston we have a problem!" << endl;
  //   cout << "Reserved " << extStr.size()+1 << " characters" << endl;
  //   cout << "This extension is " << extStr.size() << " chars long!" <<endl;
  //   exit(0);
  // };
  strcpy(pch_str, extStr.c_str());
  pch = strtok(pch_str, " ,:[]");
  if (pch != NULL) {
    nodeID = string(pch);
    extension->insert(nodeID);
    pch = strtok(NULL, " ,:[]");
    while (pch != NULL) {
      nodeID = string(pch);
      extension->insert(nodeID);
      pch = strtok(NULL, " ,:[]");
    };
    return true;
  };
  return true;
}

bool
match_sols(unordered_set<ExtArgId_T> * sol_one,
           unordered_set<ExtArgId_T> * sol_two) {
  return ((*sol_one) == (*sol_two));
}

bool
read_solutions(unordered_set<unordered_set<ExtArgId_T> *> * allExtSols) {
  // Attempt to find and check solutions
  string inputStr, solStr;
  ifstream infile;
  bool error;
  int lineNum=0;
  unordered_set<ExtArgId_T> * extSol;
  infile.open(solutionName.c_str(), ifstream::in);
  if (infile) {
    error = false;
    while (!infile.eof() && !error) {
      getline(infile, inputStr);
      lineNum++;
      size_t firstBracket = inputStr.find("[");
      size_t solBeg;
      if (problem["type"].find("SE")==string::npos) {
        solBeg=inputStr.find("[",firstBracket+1);
      } else {
        solBeg=firstBracket;
      };
      size_t solEnd=inputStr.find("]");
      while (solBeg!=string::npos && !error) {
        solStr=inputStr.substr(solBeg,solEnd-solBeg+1);
        extSol = new unordered_set<ExtArgId_T>;
        if (read_extension(solStr,extSol)) {
          allExtSols->insert(extSol);
        } else {
          error = true;
        };
        inputStr=inputStr.substr(solEnd+1,inputStr.length());
        solBeg=inputStr.find("[",solBeg);
        solEnd=inputStr.find("]");
      };
    };
    infile.close();
  } else {
    cout << "Solution file " << solutionName << " not found!" << endl;
    wait();
    error = true;
  };
  return (!error);
}

bool
check_solutions(sol_col_type * allIntSols, bool verbose) {
  bool sound = false;
  bool complete = false;
  unordered_set<unordered_set<ExtArgId_T> *> * allExtSols = new unordered_set<unordered_set<ExtArgId_T> *>;
  allExtSols->reserve(1000);
  if (read_solutions(allExtSols)) {
    //cout << "Read all external solutions." << endl;
    if (verbose) {
      cout << "External solutions:\n";
      if (problem["type"].find("SE")==string::npos) {
        display("[");
      };
      for (unordered_set<unordered_set<ExtArgId_T> *>::iterator extSolIt=allExtSols->begin();
          extSolIt!=allExtSols->end(); extSolIt++) {
        display_set(*extSolIt);
        if (next(extSolIt)!=allExtSols->end()) { display(","); };
      };
      if (problem["type"].find("SE")==string::npos) {
        display("]");
      };
    };
    unordered_set<unordered_set<ExtArgId_T> *> * intSols =
        new unordered_set<unordered_set<ExtArgId_T> *>;
    unordered_set<ExtArgId_T> * intSol;
    for (sol_col_type::const_iterator intSolIt=allIntSols->begin();
        intSolIt!=allIntSols->end(); intSolIt++) {
      intSol = new unordered_set<ExtArgId_T>;
      // cout << "Sol: " << intSolIt->size(); cout << endl;
      intSol->reserve(intSolIt->size());
      for (sol_type::const_iterator aSol=intSolIt->begin();
          aSol!=intSolIt->end();
          aSol++) {
        if (aSol->second==IN) {
          intSol->insert(getExtArgId(aSol->first));
        };
      };
      intSols->insert(intSol);
    };
    //
    // At this point allIntSols will have all computed extensions
    //
    unordered_set<unordered_set<ExtArgId_T> *>::iterator extSolIt=allExtSols->begin();
    bool thisFound, allFound=true;
    while (allFound && (extSolIt!=allExtSols->end())) {
      unordered_set<unordered_set<ExtArgId_T> *>::iterator intSolIt=intSols->begin();
      thisFound = false;
      while ((!thisFound) && (intSolIt!=intSols->end())) {
        if (match_sols(*intSolIt,*extSolIt)) {
          thisFound = true;
        };
        intSolIt++;
      };
      if (!thisFound) {
        if (verbose) {
          cout << endl << "ERROR: Missing extension "; display_set(*extSolIt);
          cout << " in computed solutions!" << endl;
        };
      };
      allFound = thisFound;
      if (allFound) { extSolIt++; };
    };
    if (allFound) {
      complete = true;
    };
    unordered_set<unordered_set<ExtArgId_T> *>::iterator intSolIt=intSols->begin();
    allFound=true;
    while (allFound && (intSolIt!=intSols->end())) {
      thisFound = false;
      unordered_set<unordered_set<ExtArgId_T> *>::iterator extSolIt=allExtSols->begin();
      while (!thisFound && (extSolIt!=allExtSols->end())) {
        if (match_sols(*intSolIt,*extSolIt)) {
          thisFound = true;
        };
        extSolIt++;
      };
      if (!thisFound) {
        if (verbose) {
          cout << endl << "ERROR: Computed extension "; display_set(*intSolIt);
          cout << " not found in external solutions!";
          cout << endl;
        };
      };
      allFound = thisFound;
      if (allFound) { intSolIt++; };
    };
    if (allFound) {
      sound = true;
    };
  };
  if (verbose) {
    cout << endl;
    if (sound && complete) {
      display("OK"); cout << endl;
    } else {
      display("ERROR"); cout << endl;
      // wait();
    };
  };
  return (sound && complete);
}


void
display_solutions (sol_col_type * sols) {
  if (stepCount) {
    cout << "Args: " << argList.size() << " transition steps: " << stepCtr << " recursive calls: "
        << findExtsCtr << endl;
  };
  if ((problem["type"].substr(0,1)=="E") || (problem["type"].substr(0,1)=="S")) {
    if (problem["type"].substr(0, 1) == "S") {
      if (sols->size() > 0) {
        display_one_extension(*(sols->begin()));
      } else {
        cout << "NO";
      };
    } else {
      cout << "[";
      for (sol_col_type::const_iterator thisSol=sols->begin();
          thisSol!=sols->end(); thisSol++) {
        display_one_extension(*thisSol);
        if (next(thisSol)!=sols->end()) {
          cout << ",";
        };
      };
      cout << "]";
    };
  } else {
    if ((problem["type"].substr(0,1)=="D") || (problem["type"].substr(1,1)=="C")) {
      if (globalSuccess) {
        cout << "YES" << endl;
      } else {
        cout << "NO" << endl;
      };
    };
  };
  cout << endl;
}

void
computeGrounded(sol_col_type & partialSols) {
  // Initialising all values to undecided:
  shared_ptr<sol_type> v_equil(new sol_type);
  sol_type v_zero;
  for (unordered_map<IntArgId_T,ArgNode_T>::iterator it = argList.begin();
      it != argList.end(); it++) {
    v_zero[it->first] = UND;
  };
  vector<sccLayerTuple *>::iterator it=sccLayers.begin();
  while (it!=sccLayers.end()) {
    IntArgId_T totLevArgs = 0;
    unordered_set<IntArgId_T> levelNodeList;
    for (vector<sccTuple *>::iterator it2=(*it)->nonTrivialSCCs.begin();
        it2!=(*it)->nonTrivialSCCs.end(); it2++) {
      totLevArgs = totLevArgs + (*it2)->nodes.size();
    };
    // Reserving space for all arguments in the non-trivial SCCs
    levelNodeList.reserve(totLevArgs);
    // cout << "This level has " << totLevArgs << " arguments." << endl;

    trivialGrounder((*it)->trivialSCC.nodes, argList, v_zero, *v_equil.get());
    //cout << "Grounded trivial SCC block!" << endl;
    // wait();
    if (it!=sccLayers.end()) {
      // cout << "Setting initial values for trivial nodes..." << endl;
      for (set<IntArgId_T>::iterator it2=(*it)->trivialSCC.nodes.begin();
          it2!=(*it)->trivialSCC.nodes.end(); it2++) {
        v_zero[*it2]=v_equil->at(*it2);
      };
    };
    //    for (set<IntArgId_T>::iterator it2=(*it)->trivialSCC.nodes.begin();
    //            it2!=(*it)->trivialSCC.nodes.end(); it2++) {
    //      cout << getExtArgId(*it2) << "=" << getArgLabel(v_equil->at(*it2)) << endl;
    //    };

    // cout << "There are " << (*it)->nonTrivialSCCs.size() << " non-trivial SCCs." << endl;
    // Inserting nodes of all non-trivial SCCs
    int ntCtr=0;
    for (vector<sccTuple *>::iterator it2=(*it)->nonTrivialSCCs.begin();
        it2!=(*it)->nonTrivialSCCs.end(); it2++) {
      ntCtr++;
      // cout << "Processing non-trivial SCC " << ntCtr << " with " << (*it2)->nodes.size() << " nodes." << endl;
      for (set<IntArgId_T>::iterator it3=(*it2)->nodes.begin();
          it3!=(*it2)->nodes.end(); it3++) {
        levelNodeList.insert(*it3);
      };
    };
    // cout << "Processed all non-trivial SCCs." << endl;
    // Compute this layer;
    // cout << "Invoking grounder for non-trivial SCCs." << endl;
    efficientGrounder(levelNodeList, argList, v_zero, *v_equil.get());
    // cout << "Finished grounder for non-trivial SCCs." << endl;
    it++;
    if (it!=sccLayers.end()) {
      // Setting initial value of preceding nodes to their equilibrium values
      // cout << "Setting initial values for non-trivial nodes..." << endl;
      for (unordered_set<IntArgId_T>::iterator it2=levelNodeList.begin(); it2!=levelNodeList.end(); it2++) {
        v_zero[*it2]=v_equil->at(*it2);
      };
    };
  };
  partialSols.insert(*v_equil);
  // Round up equilibrium values:
  // round_up_values(v_equil);
};

void
ground_layer(const unordered_set<IntArgId_T> & layerNodeList,
             const sol_type & condSol,
             sol_type & condLayerSol) {
  // layerNodeList: a list of nodes in this layer
  // layerMember: an association between a node and the layer it belongs to
  // prevLayersCondSol: a solution to nodes in preceding layers
  // condLayerSol: the result of conditioning the nodes in LayerNodeList with
  //               the solution

  sol_type v_zero;
  sol_type v_equil;
  // Initialise all values in the layer to undecided, gather values of attackers
  // from solution in this branch
  // cout << "Conditioning solution: ";
  // display_one_solution(prevLayersCondSol); cout << endl;
  for (unordered_set<IntArgId_T>::const_iterator it = layerNodeList.begin();
      it != layerNodeList.end(); it++) {
    // cout << "Node " << getExtArgId(*it) << " is in layer "
    //	 << getLayer(*it) << endl;
    for (vector<IntArgId_T>::iterator attIt=argList[*it].attsIn.begin();
        attIt!=argList[*it].attsIn.end(); attIt++) {
      // cout << "Looking for value of attacker " << getExtArgId(*attIt)
      //      << " in layer " << getLayer(*attIt) << endl;
      if (getLayer(*attIt) < getLayer(*it)) {
        // This attacker is in a previous layer, so we use its
        // already calculated value (otherwise the attacker is also
        // in this layer
        v_zero[*attIt] = condSol.at(*attIt);
        // We can do something here with nodes whose values can no longer change!
        // OPT
      };
    };
    v_zero[*it]=UND;
  };
  // cout << "Calling efficient grounder..." << endl;
  efficientGrounder (layerNodeList, argList, v_zero, v_equil);
  condLayerSol=v_equil;
};

void
ground_whole_graph(sol_type & grSol) {
  sol_type v_zero; // Not used, but needed for GRIS
  // Initialise all values of the nodes to undecided, gather values of attackers
  // from solution in prevVal
  unordered_set<IntArgId_T> graphNodeList;
  graphNodeList.reserve(argList.size());
  for (unordered_map<IntArgId_T,ArgNode_T>::iterator it = argList.begin();
      it != argList.end(); it++) {
    graphNodeList.insert(it->first);
    v_zero[it->first]=UND;
  };
  efficientGrounder(graphNodeList, argList, v_zero, grSol);
};

bool
parsOK(char ** argv[],int * argc)
{
  bool parError = false;
  bool onlyquery = false;
  string parameter;
  executableName = (*argv)[0];
  if ((*argc) == 1) {
    cout << "EqArgSolver v2.76" << endl
        << "Copyright Odinaldo Rodrigues, 2017" << endl;
    display_usage();
    return false;
  } else {
    parameter = (*argv)[1];
    transform(parameter.begin(), parameter.end(), parameter.begin(),
              ::toupper);
    if (parameter == "--FORMATS") {
      cout << "[";
      for (unsigned int idx2 = 0; idx2 < supportedFormats.size(); idx2++) {
        cout << supportedFormats[idx2];
        if (idx2 < (supportedFormats.size() - 1)) {
          cout << ",";
        };
      };
      cout << "]" << endl;
      onlyquery = true;
    }
    else {
      if (parameter == "--PROBLEMS") {
        cout << "[";
        for (unsigned int idx2 = 0; idx2 < supportedProbs.size(); idx2++) {
          cout << supportedProbs[idx2];
          if (idx2 <(supportedProbs.size() - 1)) {
            cout << ",";
          };
        };
        cout << "]" << endl;
        onlyquery = true;
      }
      else {
        int idx = 1;
        while ((idx < (*argc)) && (!parError)) {
          parameter = (*argv)[idx];
          transform (parameter.begin(), parameter.end(), parameter.begin(),
                     ::toupper);
          // Detected "problem" argument
          if (parameter.substr(0, 2) == "-P") {
            if (problem.find("type") == problem.end()) {
              if (parameter.size() > 2) {
                // Problem description supplied without a blank space
                parameter = parameter.substr(2); // Get rid of -P
                transform(parameter.begin(),parameter.end(),
                          parameter.begin(),::toupper);
                parError = !parError && (find(supportedProbs.begin(), supportedProbs.end(),
                                              parameter) == supportedProbs.end());
                if (parError) {
                  cout << "Invalid problem specified: \"" << parameter
                      << "\"! Aborting. " << endl;
                  problem.erase("type");
                } else {
                  size_t dashPos=parameter.find_last_of("-");
                  if (dashPos != string::npos) {
                    problem["type"]=parameter.substr(dashPos-2,2);
                    problem["semantics"]=parameter.substr(dashPos+1,parameter.length()-dashPos);
                  } else {
                    problem["type"]=parameter.substr(parameter.find_first_not_of(' '));
                    problem["semantics"]="D3"; // Mock semantics
                  }
                };
              } else {
                // Problem description supplied with a blank space
                // Need to get problem type from next argument
                if ((idx + 1) < (*argc)) {
                  idx++;
                  parameter = (*argv)[idx];
                  transform(parameter.begin(), parameter.end(),
                            parameter.begin(), ::toupper);
                  parError = !parError && (find(supportedProbs.begin(), supportedProbs.end(),
                                                parameter)
                      == supportedProbs.end());
                  if (parError) {
                    cout << "Invalid problem specified! Aborting. " << endl;
                  } else {
                    size_t dashPos=parameter.find_first_of("-");
                    if (dashPos != string::npos) {
                      problem["type"]=parameter.substr(dashPos-2,2);
                      problem["semantics"]=parameter.substr(dashPos+1,parameter.length()-dashPos);
                    } else {
                      problem["type"]=parameter.substr(parameter.find_first_not_of(' '));
                      problem["semantics"]="D3"; // Mock semantics
                    }
                  };
                }
                else {
                  parError = true;
                  cout << "Problem not specified! Aborting. " << endl;
                };
              };
            } else {
              parError = true;
              cout << "Multiple instances of same parameter detected! Aborting." << endl;
            };
          };

          // Detected "format" argument
          if (parameter.substr(0, 3) == "-FO") {
            if (problem.find("format") == problem.end()) {
              if (parameter.size() > 3) {
                problem["format"] = parameter.substr(3);
                transform(problem["format"].begin(),
                          problem["format"].end(),
                          problem["format"].begin(),
                          ::tolower);
                if (find(supportedFormats.begin(),
                         supportedFormats.end(),
                         problem["format"]) == supportedFormats.end()) {
                  cout << parameter.substr(3) << ": invalid graph format! Aborting. " << endl;
                  parError = true;
                };
              } else {
                if ((idx + 1) < (*argc)) {
                  idx++;
                  problem["format"] = (*argv)[idx];
                  transform(problem["format"].begin(),problem["format"].end(),
                            problem["format"].begin(), ::tolower);
                  if (find(supportedFormats.begin(), supportedFormats.end(),
                           problem["format"]) == supportedFormats.end()) {
                    cout << (*argv)[idx] << ": invalid graph format! Aborting. " << endl;
                    parError = true;
                  };
                }
                else {
                  parError = true;
                  cout << "File format not specified! Aborting. " << endl;
                };
              };
            } else {
              parError = true;
              cout << "Multiple instances of same parameter detected! Aborting." << endl;
            };
          };

          // Detected filename parameter
          // Check for File parameter. If it exists, return it on variable filename.",
          // Otherwise, makes "parError" true.
          if ((parameter.substr(0, 2) == "-F") && (parameter.substr(0, 3) != "-FO")) {
            if (problem.find("filename") == problem.end()) {
              if (parameter.size() > 2) {
                parameter = (*argv)[idx]; // Restore original non-capitalised parameter
                problem["filename"] = parameter.substr(2);
              } else {
                if ((idx + 1) < (*argc)) {
                  idx++;
                  problem["filename"] = (*argv)[idx];
                } else {
                  parError = true;
                };
              };
            } else {
              parError = true;
              cout << "Multiple instances of same parameter detected! Aborting. -F" << endl;
            };
          };

          // Check for Additional argument parameter.
          // If it exists, return it on variable argument.",
          // Otherwise, makes "parError" true.
          if (parameter.substr(0, 2) == "-A") {
            if (problem.find("argument")==problem.end()) {
              if (parameter.size() > 2) {
                // Restore original non-capitalised parameter
                parameter=(*argv)[idx];
                problem["argument"] = parameter.substr(2);
              }  else {
                if ((idx + 1) < (*argc)) {
                  idx++;
                  problem["argument"] = (*argv)[idx];
                }  else {
                  parError = true;
                  cout << "Additional argument not specified! Aborting. "
                      << endl;
                };
              };
            } else {
              parError = true;
              cout << "Multiple instances of same parameter detected! Aborting.\n";
            };
          };

          // Detected strategy for selecting arguments to label IN
          if (parameter.substr(0, 2) == "-S") {
            if (parameter.size() > 2) {
              parameter=parameter.substr(2,1);
              if (parameter=="F") {
                __policy=FIRST;
              } else {
                __policy = stoi(parameter);
                if ((__policy > 3) || (__policy < 0)) {
                  __policy=FIRST; // This means, no selection, take the first in list
                };
              };
            }  else {
              if ((idx + 1) < (*argc)) {
                idx++;
                parameter=(*argv)[idx];
                transform (parameter.begin(), parameter.end(), parameter.begin(),
                           ::toupper);
                parameter=parameter.substr(0,1);
                if (parameter=="F") {
                  __policy=FIRST;
                } else {
                  __policy = stoi(parameter);
                  if ((__policy > 3) || (__policy < 0)) {
                    __policy=FIRST;
                  };
                };
              }  else {
                parError = true;
                cout << "Strategy not specified! Aborting. "
                    << endl;
              };
            };
          };


          // Detect for verbose parameter
          if (parameter.substr(0,2) == "-V") {
            problem["verbose"] = "true";
            verbOutput = true;
          };

          // Detect for quickMode parameter
          if (parameter.substr(0,2) == "-Q") {
            quickMode = true;
          };

          if (parameter.substr(0,3) == "-MC") {
            sccCompMethod = MODGIL_CAMINADA;
          };
          if (parameter.substr(0,6) == "-NOFAL"){
            sccCompMethod = NOFAL;
          };
          if (parameter.substr(0,8) == "-NOF_ODI"){
            sccCompMethod = NOF_ODI;
          };
          if (parameter.substr(0,9) == "-MOS_ODIN"){
            sccCompMethod = MOS_ODIN;
          };
          if (parameter.substr(0,5) == "-ODIN"){
            sccCompMethod = ODIN_PURE;
          };

          // Detect for verify parameter
          if ((parameter.substr(0, 2) == "-C") &&
	      (parameter.substr(0, 3) != "-CL")) {
            checkSols = true;
          };
          if (parameter.substr(0, 2) == "-T") {
            stepCount = true;
          };
          if (parameter.substr(0, 3) == "-CL") {
            useConflicts = true;
          };
          if (parameter.substr(0, 5) == "-NOCL") {
            useConflicts = false;
          };
          if (parameter.substr(0, 6) == "-TRACE") {
            trace = true;
          };

          idx++;
        };
      };
    };
    if ((!onlyquery) && (!parError)) {
      if (problem.find("type")==problem.end() ||
          problem.find("semantics")==problem.end()) {
        parError = true;
        cout << "Problem type not specified!" << endl;
      };
      if (problem.find("format")==problem.end()) {
        cout << "File format not specified!" << endl;
        parError = true;
      };
      if (problem.find("filename")==problem.end()) {
        cout << "Input filename not specified!" << endl;
        parError = true;
      };

      if (!parError) {
        if ((problem["type"].substr(0, 2) == "DS") ||
            (problem["type"].substr(0, 2) == "DC")) {
          if (problem.find("argument") == problem.end()) {
            cout << "Missing argument to be checked! Aborting." << endl;
            parError=true;
          };
        } else {
          if (problem.find("argument") != problem.end()) {
            // Ignoring redundant argument parameter in enumeration problem.
          };
          problem["argument"]="";
        };
      };
      if (parError) {
        display_usage();
      };
    } else {
      parError = true;
    }
  };
  return(!parError);
}

void
define_functionality() {
  supportedProbs.push_back("DC-GR");
  supportedProbs.push_back("SE-GR");
  // supportedProbs.push_back("DS-GR"); Removed in ICCMA 2017
  // supportedProbs.push_back("EE-GR"); Removed in ICCMA 2017
  supportedProbs.push_back("DC-PR");
  supportedProbs.push_back("DS-PR");
  supportedProbs.push_back("EE-PR");
  supportedProbs.push_back("SE-PR");
  supportedProbs.push_back("DC-CO");
  supportedProbs.push_back("DS-CO");
  supportedProbs.push_back("EE-CO");
  supportedProbs.push_back("SE-CO");
  supportedProbs.push_back("EE-ST");
  supportedProbs.push_back("SE-ST");
  supportedProbs.push_back("DC-ST");
  supportedProbs.push_back("DS-ST");
  supportedProbs.push_back("D3");
  supportedFormats.push_back("tgf");
}

void
computeOthers (sol_col_type & partialSols) {
  int lastLayer;
  int thisLayer = 0;
  stepCtr = 0;
  //sol_col_type completeSols;
  unordered_set<IntArgId_T> layerNodeList;
  sol_col_type allLayerSols;
  sol_type emptySol;
  partialSols.insert(emptySol);
  if (decisionProblem && !stableSemantics) {
    lastLayer = getLayer(intArgToFind);
    // Decision problem. Last layer to check is the layer in which the
    // argument to find is located.
  } else {
    lastLayer = sccLayers.size() - 1;
  };
  bool endSearch = false;
  while ((thisLayer <= lastLayer) && !endSearch) {
    // cout << "Layer: " << thisLayer << endl;

    //////////////////////////////////////////////////////////////////////////////////
    ///                           PROCESSING LAYER                                 ///
    //////////////////////////////////////////////////////////////////////////////////

    int partSolIdx = 0;
    sol_col_type newPartialSols;
    // cout << "Working from previous solutions:" << endl;
    // display_all_solutions(partialSols); cout << endl;
    // wait("Starting new layer...");
    sol_col_type::iterator thisSol =
        partialSols.begin();
    bool successInThisSol;
    // int solIdx=0;
    while ((thisSol != partialSols.end()) && !endSearch) {
      // cout << "Solution " << solIdx << endl;
      // solIdx++;
      ///////////////////////////////////////////////////////////////////////////////
      ///                      PROCESSING PARTIAL SOLUTION                        ///
      ///////////////////////////////////////////////////////////////////////////////
      partSolIdx++;
      // cout << "Collecting layer nodes:" << endl;
      collect_layer_nodes(thisLayer,&layerNodeList);
      // cout << "Collected layer nodes." << endl;
      // sol_type grLayerSol;
      // grLayerSol will store the result of grounding the nodes in this layer with
      // a solution (in this case *thisSol)
      // Ground layer propagates the values of previous solution "thisSol" into
      // "grLayerSol"
      successInThisSol = false;
      // cout << "Grounding layer with solution "; display_one_solution(*thisSol); cout << endl;
      // cout << "Nodes in the layer: "; display_set(layerNodeList); cout << endl;
      // ground_layer(layerNodeList,(*thisSol),grLayerSol);
      //      cout << "Grounded layer:" << endl;
      //      display_one_solution(grLayerSol); cout << endl;
      allLayerSols.erase(allLayerSols.begin(), allLayerSols.end());
      // cout << "Processing trivial SCC block" << endl;
      //////////////////////////////////////////////////////////////////////////////
      ///                   PROCESSING TRIVIAL SCC BLOCK                         ///
      //////////////////////////////////////////////////////////////////////////////
      // cout << "====>>>>>Ready to process " << sccLayers[thisLayer]->trivialSCC.nodes.size() << " trivial SCC(s)" << endl;

      // Check Trivial SCC:
      sol_type trivialSol;
      if (sccLayers[thisLayer]->trivialSCC.nodes.size() > 0) {
        // poss_INs_in_scc returns the trivial SCC values and only those in trivialSol
        // All we need here is to extract the pairs of node=value from grLayerSol
        // cout << "Grounding trivial SCC block." << endl;
        groundingTimer.resume();
        trivialGrounder(sccLayers[thisLayer]->trivialSCC.nodes,argList,(*thisSol),trivialSol);
        groundingTimer.pause();
        // cout << "Result: "; display_one_solution(trivialSol); cout << endl;
        // No longer needed:
        // getSCCSol(sccLayers[thisLayer]->trivialSCC.nodes, grLayerSol, trivialSol);
        // poss_INs_in_scc(&sccLayers[thisLayer]->trivialSCC,&attsIn,&attsOut,
        //      *thisSol, grLayerSol, trivialSol, poss_ins);
        // poss_ins->size > 0: ERROR!
      };
      allLayerSols.insert(trivialSol);
      // Inserting trivial solution into this layer's solutions.
      if (decisionProblem && (thisLayer == lastLayer)) {
        if (sccLayers[thisLayer]->trivialSCC.nodes.find(intArgToFind)
            !=sccLayers[thisLayer]->trivialSCC.nodes.end()) {
          // The argument is in this trivial SCC!
          successInThisSol = (trivialSol[intArgToFind]==IN);
          if (!stableSemantics) {
            if (skeptical) {
              // This is a skeptical check.
              // Argument not IN ends search with failure
              if (!successInThisSol) {
                globalSuccess = false;
                endSearch = true;
                stableSafe = true;
              } else {
                // Argument is IN but may not yet end search
                if (is_last(thisSol,partialSols)) {
                  endSearch = true;
                  globalSuccess = true; // No need to look at the non-trivial SCCs
                };
              };
            } else {
              if (successInThisSol) {
                // Our search can terminate here.
                endSearch = true;
                globalSuccess = true;
              };
            };
          };
        };
      };
      ///////////////////////////////////////////////////////////////////////////////
      ///                  END OF PROCESSING TRIVIAL SCC BLOCK                    ///
      ///////////////////////////////////////////////////////////////////////////////
      // cout << "Processing non-trivial SCC block" << endl;


      sol_col_type ntSCCSols;
      // ntSCCSols.reserve(10000);
      vector<sccTuple *>::iterator ntsccIt =
          sccLayers[thisLayer]->nonTrivialSCCs.begin();
      // cout << "====>>>>>Ready to process " << sccLayers[thisLayer]->nonTrivialSCCs.size() << " non-trivial SCC(s)" << endl;
      while (!endSearch &&
          (ntsccIt != sccLayers[thisLayer]->nonTrivialSCCs.end())) {
        // cout << "Processing SCC "; display_set((*ntsccIt)->nodes); cout << endl;

        ////////////////////////////////////////////////////////////////////////////
        ///                      PROCESSING NON-TRIVIAL SCC                      ///
        ////////////////////////////////////////////////////////////////////////////
        // NEEDS ATTENTION
        ntSCCSols.clear();
        unordered_set<IntArgId_T> poss_ins;
        poss_ins.reserve((*ntsccIt)->nodes.size());
        sol_type initSol, partSol;
	// groundingTimer.resume();
        // ground_scc((*ntsccIt)->nodes,(*thisSol),initSol); // 0.09s
        // groundingTimer.pause();
        // get_partial_sol((*ntsccIt)->nodes,(*thisSol),initSol,partSol);

	groundingTimer.resume();
        new_ground_scc((*ntsccIt)->nodes,(*thisSol),partSol); // 0.09s
        groundingTimer.pause();


        // cout << "Wrong computation of partial solution:" << endl;
        // cout << "Cond: "; display_one_solution(*thisSol); cout << endl;
        // cout << "Old:  "; display_one_solution(partSol); cout << endl;
        // cout << "New:  "; display_one_solution(newPartSol); cout << endl;
	// if (partSol!=newPartSol) {
        //   exit(0);
        // }
        // cout << "Initial solution: "; display_one_solution(initSol); cout << endl;
        // cout << "Partial solution: "; display_one_solution(partSol); cout << endl;
        // cout << "Nodes that can be IN: "; display_set(poss_ins); cout << endl;

        if ((sccCompMethod == MODGIL_CAMINADA) || true) {
          if (decisionProblem && (thisLayer == lastLayer) && !stableSemantics) {
            if ((*ntsccIt)->nodes.find(intArgToFind) != (*ntsccIt)->nodes.end()) {
              if (partSol.at(intArgToFind) == UND) {
		successInThisSol = false;
		if (is_last(thisSol,partialSols)) {
		  globalSuccess = false;
		  endSearch = true;
		};
              } else {
                if (partSol.at(intArgToFind) == OUT) {
                  if (is_last(thisSol,partialSols)) {
                    globalSuccess = false;
                    endSearch = true;
                  };
                };
                // The argument we are looking for is in this SCC and cannot
                // possibly be IN
              };
            };
          };
          if (!endSearch) {
            // Need to spawn solutions!!!
            sol_type compSol;
            complete_solution(partSol,compSol);
            ntSCCSols.insert(compSol);
            deep = false;
            //if (!thisExt.empty()) {
            //  cout << problem["filename"] << ": some nodes labelled IN in SCC "; display_set((*ntsccIt)->nodes);
            //  cout << ": "; display_set(thisExt); cout  << endl;
            //  wait();
            //Don't sdt};
            size_t thisSavedFromConflicts=0;
            unordered_set<unordered_set<IntArgId_T>,setHash> sccConflicts;
            solutionTimer.resume();
            // cout << "Invoking PURE..." << endl;
	    // timer t;
	    // t.reset();
	    // t.resume();
	    // cout << "Layer " << thisLayer << " Solution " << solIdx
	    // 	 << " SCC " << (*ntsccIt)->nodes.size() << " >";
            findSCCSols((*ntsccIt)->nodes,
                        (*thisSol),
                        partSol,
                        ntSCCSols,
                        sccConflicts,
                        thisSavedFromConflicts,
                        "");
	    // t.pause();
	    // cout << " Time spent: " << t.milli_elapsed() << endl; 
//            for (auto sccSol : ntSCCSols) {
//              display_one_solution(sccSol); cout << endl;
//            };
//            wait();
            sol_col_type compSCCSols;
            for (auto sccSol : ntSCCSols) {
              // display_one_solution(sccSol); cout << endl;
              complete_solution(sccSol,compSol);
              compSCCSols.insert(compSol);
            };
            ntSCCSols=compSCCSols;
            solutionTimer.pause();
            set_stats(thisSavedFromConflicts,sccConflicts.size(),ntSCCSols.size());
          }; // else: success is impossible for argument
          if (!endSearch &&
              decisionProblem &&
              ((*ntsccIt)->nodes.find(intArgToFind) != (*ntsccIt)->nodes.end())) {
            // This is a decision problem for an argument which is in this
            // non-trivial SCC. So we may be able to terminate the search here if:
            // - the search is skeptical search and the argument is not IN
            //   in some solution
            // - the search is credulous, not in the stable semantics and the
            //   argument is IN in at least one solution

            bool sccSolSuccess = false;
            bool sccAllSolsSuccess = true;
            sol_col_type::iterator it = ntSCCSols.begin();
            while (it != ntSCCSols.end() && !endSearch) {
              sccSolSuccess = (it->at(intArgToFind) == IN);
              if (!sccSolSuccess) {
                sccAllSolsSuccess = false;
                if (skeptical && !stableSemantics) {
                  globalSuccess = false;
                  endSearch = true;
                };
              } else {
                if (!skeptical && !stableSemantics) {
                  globalSuccess = true;
                  endSearch = true;
                };
              };
              it++;
            };
            if (skeptical) {
              if (!stableSemantics) {
                if (sccAllSolsSuccess) {
                  // This is a skeptical problem and all solutions of this partial
                  // solution were successful. We can terminate
                  // the search only if there are no further partial solutions...
                  if (is_last(thisSol,partialSols)) {
                    globalSuccess = true;
                    endSearch = true;
                  };
                } else {
                  globalSuccess = false;
                  // This is a skeptical problem and one solution failed. We can
                  // terminate the search here with FAILURE.
                  endSearch = true;
                };
              };
            };
          };
          if (!endSearch) {
            // All solutions to this SCC calculated.
            // Combine solutions of this SCC...
            compositionTimer.resume();
            sol_type baseSol;
            sol_col_type newAllLayerSols;
            for (sol_col_type::iterator mainIt =
                allLayerSols.begin(); mainIt != allLayerSols.end(); mainIt++) {
              baseSol = *mainIt;
              // Duplicating layer solution
              int solIdx=0;
              for (sol_col_type::iterator sccSolIt =
                  ntSCCSols.begin(); sccSolIt != ntSCCSols.end(); sccSolIt++) {
                // Append partial solution sccSolIt to baseSol
                solIdx++;
                for (sol_type::const_iterator nodeIt =
                    sccSolIt->begin(); nodeIt != sccSolIt->end(); nodeIt++) {
                  baseSol[nodeIt->first] = nodeIt->second;
                };
                if (problem["semantics"].find("ST") != string::npos) {
                  bool ok = true;
                  sol_type::iterator it=baseSol.begin();
                  while (ok && (it!=baseSol.end())) {
                    ok = (it->second != UND);
                    it++;
                  };
                  if (ok) {
                    newAllLayerSols.insert(baseSol);
                  };
                } else {
                  newAllLayerSols.insert(baseSol);
                };
              };
            };
            compositionTimer.pause();
            allLayerSols = newAllLayerSols;
          }; // endSearch!
        } else {
          // cout << "Non-trivial SCC with NO undecided nodes." << endl;
          // Non-trivial SCC with NO undecided nodes. Nothing to do except to
          // combine solutions.

          // Non-trivial SCC with NO undecided nodes. Nothing to do except to
          // combine solutions.
          if (decisionProblem &&
              (thisLayer == lastLayer) &&
              ((*ntsccIt)->nodes.find(intArgToFind)!= (*ntsccIt)->nodes.end())) {
            // The argument is in this SCC
            successInThisSol = (initSol[intArgToFind] == IN);
            if (!skeptical) {
              if (!stableSemantics) {
                if (successInThisSol) {
                  globalSuccess = true;
                  endSearch = true;
                };
              };
            } else {
              if (!stableSemantics) {
                if (successInThisSol) {
                  if (is_last(thisSol,partialSols)) {
                    globalSuccess = true;
                    endSearch = true;
                  };
                } else {
                  globalSuccess= false;
                  endSearch = true;
                };
              };
            };
          };
          if (!endSearch) {
            sol_type baseSol;
            sol_col_type newAllLayerSols;
            compositionTimer.resume();
            for (sol_col_type::iterator mainIt =
                allLayerSols.begin(); mainIt != allLayerSols.end(); mainIt++) {
              baseSol = *mainIt;
              for (set<IntArgId_T>::iterator nodeIt = (*ntsccIt)->nodes.begin();
                  nodeIt != (*ntsccIt)->nodes.end(); nodeIt++) {
                baseSol[*nodeIt] = initSol[*nodeIt];
              };
              newAllLayerSols.insert(baseSol);
            };
            compositionTimer.pause();
            allLayerSols = newAllLayerSols;
          };
          // Calculated all solutions to SCC ntsccIt in layer thisLayer for
          // solution thisSol
        };
        // cout << "Proceeding to next non-trivial SCC." << endl;
        ntsccIt++;
      };
      ///////////////////////////////////////////////////////////////////////////
      ///                 END OF PROCESSING NON-TRIVIAL SCC BLOCK             ///
      ///////////////////////////////////////////////////////////////////////////
      // cout  << "Processed all SCCs in this layer." << endl;
      if (!endSearch) {
        // Calculated all solutions to all SCCs in thisLayer
        // Combine layer solutions with this partial solution
        sol_type baseSol;
        // Replicate partial solution thisSol
        compositionTimer.resume();
        for (sol_col_type::iterator solIt =
            allLayerSols.begin(); solIt != allLayerSols.end(); solIt++) {
          baseSol = *thisSol;

          // cout << "Combining solution to previous layer: ";
          // display_one_solution(baseSol); cout << endl;
          // cout << "With solution to this layer: ";
          // display_one_solution(*solIt); cout << endl;

          for (sol_type::const_iterator nodeIt = solIt->begin();
              nodeIt != solIt->end(); nodeIt++) {
            baseSol[nodeIt->first] = nodeIt->second;
          };
          // cout << "About to insert "; display_one_solution(baseSol); cout << endl;
          newPartialSols.insert(baseSol);
        };
        compositionTimer.pause();
      };
      // cout << "Proceeding to next solution." << endl;
      thisSol++;
      /////////////////////////////////////////////////////////////////////////////
      ///                  END PROCESSING PARTIAL SOLUTION                      ///
      /////////////////////////////////////////////////////////////////////////////
    };
    // cout << "Ready for next layer" << endl;
    // cout << "Solutions to previous layer:" << endl;
    // display_all_solutions(partialSols); cout << endl;
    partialSols=newPartialSols;
    // cout << "Solutions up to this layer:" << endl;
    // display_all_solutions(partialSols); cout << endl;
    // Ready for next layer.
    thisLayer++;
    ///////////////////////////////////////////////////////////////////////////////
    ///                        END PROCESSING LAYER                             ///
    ///////////////////////////////////////////////////////////////////////////////
  };
  // No more layers to process...
};

void
postProcess(sol_col_type & partialSols) {
  if (groundedSemantics && decisionProblem) {
    // There's only one solution in partialSols. If the label
    // of the argument to find is IN in that solution, success is true
    sol_type groundedSol=*partialSols.begin();
    globalSuccess = groundedSol.at(intArgToFind)==IN;
  } else {
    if (stableSemantics) {
      remove_non_stable(partialSols);
      if (decisionProblem && !stableSafe) {
        bool endSearch = false;
        sol_col_type::iterator thisSol=partialSols.begin();
        globalSuccess = ((thisSol == partialSols.end())
            && skeptical); // Default behaviour: true if there are no solutions
        // in a skeptical problem, and false otherwise.
        while (!endSearch && thisSol!=partialSols.end()) {
          if (thisSol->at(intArgToFind)==IN) {
            globalSuccess = true;
            if (!skeptical) {
              endSearch = true;
            };
          } else {
            if (skeptical) {
              globalSuccess = false;
              endSearch = true;
            };
          }
          thisSol++;
        };
      };
    };
  }
  //set<sol_type *>::iterator sol=partialSols.begin();
  //display_one_solution(*sol);
  //cout << "End of postProcess" << endl;
}

void
set_global_variables() {
  groundedSemantics = (problem["semantics"].find("GR") != string::npos);
  if ((problem["type"].find("DS") != string::npos) ||
      (problem["type"].find("DC") != string::npos)) {
    decisionProblem = true;
    // This is a decision problem. 
    intArgToFind = getIntArgId(problem["argument"]);
  } else {
    decisionProblem = false;
    intArgToFind = nullIntArgId;
  };
  skeptical = problem["type"].find("DS") != string::npos;
  stableSemantics = problem["semantics"].find("ST") != string::npos;
  triathlon = problem["type"].find("D3") != string::npos;
  char filename_str[256];
  strcpy(filename_str, problem["filename"].c_str());
  string filename = problem["filename"];
  solutionName = filename.substr(0, filename.find_last_of("."));
  if (solutionName.find_last_of("/") != string::npos) {
    solutionName.replace(solutionName.find_last_of("/"), 1, "/solutions/");
  } else {
    solutionName = "solutions/" + solutionName;
  };
  solutionName += ".apx." + problem["type"] + "-" + problem["semantics"];
  stableSafe = false;
  globalSuccess = false;
};

void
set_stacksize(int mbs) {
  const rlim_t kStackSize = mbs * 1024 * 1024;   // min stack size = 16 MB
  struct rlimit rl;
  int result;

  result = getrlimit(RLIMIT_STACK, &rl);
  if (result == 0)
  {
    if (rl.rlim_cur < kStackSize)
    {
      rl.rlim_cur = kStackSize;
      result = setrlimit(RLIMIT_STACK, &rl);
      if (result != 0)
      {
        fprintf(stderr, "setrlimit returned result = %d\n", result);
      }
    }
  }
}

int
main(int argc, char *argv[]) {
  // Increase stack size to 128MB
  set_stacksize(256);
  // Process arguments
  string parameter;
  define_functionality();
  updTime.reset();
  insTime.reset();
  cmpTime.reset();
  globalTimer.reset();
  stratTimer.reset();
  compositionTimer.reset();
  solutionTimer.reset();
  globalTimer.resume();
  groundingTimer.reset();
  if (parsOK(&argv, &argc)) {
    if (readFile()) {
      set_global_variables();
      // If we get to this point, we know we have a problem invocation
      // command with valid parameters: either not a decision problem or
      // argument to find is in the graph.

      // sanity_check();

      // Computing via decomposition of graph into layers.
      // Performs better in most cases checked.
      sol_col_type problemSols;
      // cout << "Ready to decompose and stratify." << endl;
      timer t;
      stratTimer.resume();
      decompose_and_stratify();
      stratTimer.pause();
      poss_in_timer.reset();
      if (!triathlon) {
        // This is not a Triathlon
        numRecCalls = 0;
        if (groundedSemantics) {
          computeGrounded(problemSols);
        } else {
          computeOthers(problemSols);
        };
        postProcess(problemSols);
        globalTimer.pause();
        selectTimer.reset();
        bool result = true;
        if (quickMode) {
          if (checkSols) {
            result=check_solutions(&problemSols,false);
          };
          cout << problem["filename"] << ",";
          if (checkSols) {
            (result ? cout << "OK," : cout << "ERROR,");
          } else {
            cout << "?,";
          }
          cout << globalTimer.milli_elapsed()
	       << ",NumSols=" << problemSols.size()
	       << ",Method=" << getCompMethodName(sccCompMethod)
	       << "," << getStrategyCode(__policy) << "," << getStrategyName(__policy)
	       << ",UsingConflicts=" << useConflicts
	       << "," << savedFromConflicts
	       << ",Decomposing=" << stratTimer.milli_elapsed()
	       << ",Grounding=" << groundingTimer.milli_elapsed()
	       << ",Solving SCCs=" << solutionTimer.milli_elapsed()
	       << ",CombSols=" << compositionTimer.milli_elapsed()
	    // << ",possINs=" << poss_in_timer.milli_elapsed()
	       << endl;
        } else {
          display_solutions(&problemSols);
          if (checkSols) {
            result = check_solutions(&problemSols,true);
          };
        };
        if (trace) {
          cout << "Trace: " << endl << bugstr.str() << endl;
        };
        // display_stats();
      } else {
        // First let us calculate the grounded extension
        problem["type"]="SE-GR";
        problem["semantics"]="GR";
        computeGrounded(problemSols);
        cout << "[";
        display_solutions(&problemSols);
        cout << "],";
        // Now let us compute all preferred extensions
        decisionProblem = false;
        stableSemantics = false;
        problem["type"]="EE-PR";
        problem["semantics"]="PR";
        problemSols.erase(problemSols.begin(),problemSols.end());
        computeOthers(problemSols);
        sol_col_type stableSols = problemSols;
        // Remove the non-stable extensions
        remove_non_stable(stableSols);
        // Display the remaining stable extensions
        display_solutions(&stableSols);
        cout << ",";
        // Now display the originally computed preferred extensions
        display_solutions(&problemSols);
        cout << endl;
      };
    }; // readFile
  };
}


