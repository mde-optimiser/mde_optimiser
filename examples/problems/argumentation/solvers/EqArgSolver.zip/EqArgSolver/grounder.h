/*
 * grounder.h
 *
 *  Created on: 11 Mar 2016
 *      Author: stty3154
 */

#ifndef GROUNDER_H
#define GROUNDER_H

#include <map>
#include <unordered_map>
#include <sstream>
#include <fstream>
#include <iostream>
#include <deque>
#include <queue>
#include <unordered_set>
#include <set>
#include <string>
#include <vector>
#include <math.h>
#include <limits>
#include <unistd.h>
#include <time.h>

using namespace std;

typedef unsigned char IntArgValue_T;
typedef unsigned int IntArgId_T;
typedef string ExtArgId_T;
typedef std::numeric_limits<float> max_tol;
typedef map<IntArgId_T,IntArgValue_T> sol_type;
typedef set<sol_type> sol_col_type;


struct
ArgNode_T {
  int layer;
  ExtArgId_T extArgId;
  vector<IntArgId_T> attsIn;
  vector<IntArgId_T> attsOut;
};

const IntArgValue_T IN = 2;
const IntArgValue_T OUT = 0;
const IntArgValue_T UND = 1;
const IntArgValue_T MUST_OUT = 3;
const IntArgValue_T BLANK = 4;
const long int max_ext_length = 1000000; // The maximum number of characters in an extension
const IntArgId_T maxIntArgId = numeric_limits<unsigned int>::max(); // The maximum number of arguments (16 bits) 0 -> RESERVED
const IntArgId_T nullIntArgId = 0; // The invalid internal argument Id used for special purposes

void
process_mem_usage(double& vm_usage, double& resident_set);

unsigned long long
getTotalSystemMemory();

void
mem_stats();

string
getArgLabel(IntArgValue_T argValue);

void full_approx_grounder (unordered_set<IntArgId_T> * nodeList,
			   map<IntArgId_T, vector<IntArgId_T> > * attsIn,
			   map<IntArgId_T, double> * initArray,
			   map<IntArgId_T, double> * stableArray,
			   map<IntArgId_T, double> * equilArray,
			   bool verbose,
			   double tolerance);

void fastGrounder (unordered_set<IntArgId_T> * nodeList,
		   map<IntArgId_T, vector<IntArgId_T> > * attsIn,
		   map<IntArgId_T, double> * initArray,
		   map<IntArgId_T, double> * stableArray,
		   map<IntArgId_T, double> * equilArray,
		   bool verbose,
		   double tolerance);

void efficientGrounder (const unordered_set<IntArgId_T> & nodeList,
			const unordered_map<IntArgId_T, ArgNode_T> & argList,
			const sol_type & v0,
			sol_type & ve);

void sccGrounder (const set<IntArgId_T> & nodeList,
		  const unordered_map<IntArgId_T, ArgNode_T> & argList,
		  const map<IntArgId_T, IntArgValue_T> & v0,
		  map<IntArgId_T, IntArgValue_T> & ve);

void trivialGrounder (const set<IntArgId_T> & nodeList,
                      const unordered_map<IntArgId_T, ArgNode_T> & argList,
                      const sol_type & v0,
                      sol_type & ve);

bool condPropagate (unordered_set<IntArgId_T> * nodeList,
		    IntArgId_T argToMakeIN,
		    map<IntArgId_T, vector<IntArgId_T> > * attsIn,
		    unordered_set<IntArgId_T> * def_outs,
		    map<IntArgId_T, IntArgValue_T> * initSolution,
		    map<IntArgId_T, IntArgValue_T> * equilArray);

#endif



